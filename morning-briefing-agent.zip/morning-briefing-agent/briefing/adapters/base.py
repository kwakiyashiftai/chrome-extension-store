"""
データソースアダプターの基底クラス
すべてのアダプターはこのインターフェースを実装する
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger("briefing.adapters")


class BaseAdapter(ABC):
    """データソースアダプターの基底クラス"""

    def __init__(self, config: Dict[str, Any] = None, credentials: Dict[str, Any] = None):
        """
        Args:
            config: 設定情報
            credentials: 認証情報
        """
        self.config = config or {}
        self.credentials = credentials or {}
        self.logger = logging.getLogger(f"briefing.adapters.{self.source_name}")

    @property
    @abstractmethod
    def source_name(self) -> str:
        """データソース名を返す（例: 'slack', 'github'）"""
        pass

    @property
    @abstractmethod
    def source_display_name(self) -> str:
        """表示用名称を返す（例: 'Slack', 'GitHub'）"""
        pass

    @abstractmethod
    async def authenticate(self) -> bool:
        """
        認証を実行し、成功したらTrueを返す

        Returns:
            bool: 認証成功の可否
        """
        pass

    @abstractmethod
    async def fetch_data(
        self, target_date: datetime, config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        指定日のデータを取得し、正規化フォーマットで返す

        Args:
            target_date: 取得対象日
            config: 追加設定

        Returns:
            {
                "source": str,
                "fetched_at": str (ISO format),
                "status": "success" | "error" | "partial",
                "data": dict | None,
                "error": dict | None
            }
        """
        pass

    @abstractmethod
    def get_required_scopes(self) -> List[str]:
        """必要な認証スコープのリストを返す"""
        pass

    @abstractmethod
    def get_config_schema(self) -> Dict[str, Any]:
        """設定項目のJSONスキーマを返す"""
        pass

    def _build_success_response(
        self, data: Dict[str, Any], fetched_at: datetime = None
    ) -> Dict[str, Any]:
        """
        成功レスポンスを構築

        Args:
            data: 正規化されたデータ
            fetched_at: 取得日時

        Returns:
            標準レスポンス形式
        """
        return {
            "source": self.source_name,
            "fetched_at": (fetched_at or datetime.now()).isoformat(),
            "status": "success",
            "data": data,
            "error": None,
        }

    def _build_error_response(
        self, error_code: str, error_message: str, recoverable: bool = True
    ) -> Dict[str, Any]:
        """
        エラーレスポンスを構築

        Args:
            error_code: エラーコード
            error_message: エラーメッセージ
            recoverable: リカバリー可能か

        Returns:
            標準レスポンス形式
        """
        return {
            "source": self.source_name,
            "fetched_at": datetime.now().isoformat(),
            "status": "error",
            "data": None,
            "error": {
                "code": error_code,
                "message": error_message,
                "recoverable": recoverable,
            },
        }

    def _build_partial_response(
        self, data: Dict[str, Any], error_message: str
    ) -> Dict[str, Any]:
        """
        部分成功レスポンスを構築

        Args:
            data: 取得できたデータ
            error_message: エラーメッセージ

        Returns:
            標準レスポンス形式
        """
        return {
            "source": self.source_name,
            "fetched_at": datetime.now().isoformat(),
            "status": "partial",
            "data": data,
            "error": {"message": error_message},
        }

    def validate_config(self) -> List[str]:
        """
        設定の妥当性をチェック

        Returns:
            エラーメッセージのリスト（空の場合は問題なし）
        """
        errors = []
        schema = self.get_config_schema()

        # 必須フィールドのチェック
        required = schema.get("required", [])
        for field in required:
            if field not in self.config:
                errors.append(f"{self.source_display_name}: 必須設定 '{field}' がありません")

        return errors

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(source={self.source_name}, enabled={self.config.get('enabled', False)})"
