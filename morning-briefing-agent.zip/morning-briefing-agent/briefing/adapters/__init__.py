"""
データソースアダプターモジュール
各種外部サービスからデータを取得するアダプターを提供
"""

from .base import BaseAdapter
from .slack_adapter import SlackAdapter
from .google_calendar_adapter import GoogleCalendarAdapter
from .google_docs_adapter import GoogleDocsAdapter

# 利用可能なアダプター
AVAILABLE_ADAPTERS = {
    "slack": SlackAdapter,
    "google_calendar": GoogleCalendarAdapter,
    "google_docs": GoogleDocsAdapter,
}

__all__ = [
    "BaseAdapter",
    "SlackAdapter",
    "GoogleCalendarAdapter",
    "GoogleDocsAdapter",
    "AVAILABLE_ADAPTERS",
]
