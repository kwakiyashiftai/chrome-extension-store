"""
Google Calendarアダプター
Googleカレンダーから予定を取得
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from .base import BaseAdapter

logger = logging.getLogger("briefing.adapters.google_calendar")


class GoogleCalendarAdapter(BaseAdapter):
    """Google Calendar データソースアダプター"""

    def __init__(self, config: Dict[str, Any] = None, credentials: Dict[str, Any] = None):
        super().__init__(config, credentials)
        self.service = None

    @property
    def source_name(self) -> str:
        return "google_calendar"

    @property
    def source_display_name(self) -> str:
        return "Google Calendar"

    async def authenticate(self) -> bool:
        """
        Google Calendar認証を実行

        Returns:
            認証成功の可否
        """
        try:
            # OAuth2認証情報を構築
            creds_info = {
                "token": self.credentials.get("refresh_token"),
                "refresh_token": self.credentials.get("refresh_token"),
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": self.credentials.get("client_id"),
                "client_secret": self.credentials.get("client_secret"),
                "scopes": self.get_required_scopes(),
            }

            creds = Credentials.from_authorized_user_info(creds_info)

            # Calendar APIクライアント作成
            self.service = build("calendar", "v3", credentials=creds)

            # 認証テスト
            calendar_list = self.service.calendarList().list(maxResults=1).execute()

            self.logger.info("Google Calendar認証成功")
            return True

        except Exception as e:
            self.logger.error(f"Google Calendar認証エラー: {e}")
            return False

    async def fetch_data(
        self, target_date: datetime, config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Google Calendarからデータを取得

        Args:
            target_date: 取得対象日
            config: 追加設定

        Returns:
            正規化されたデータ
        """
        if not self.service:
            await self.authenticate()

        if not self.service:
            return self._build_error_response(
                "AUTH_FAILED", "Google Calendar認証に失敗しました", recoverable=True
            )

        try:
            # カレンダーIDを取得
            calendar_id = self.config.get("calendar_id", "primary")

            # 取得期間の計算（対象日の00:00〜23:59）
            time_min = target_date.replace(hour=0, minute=0, second=0, microsecond=0)
            time_max = time_min + timedelta(days=1)

            # イベント一覧を取得
            events_result = (
                self.service.events()
                .list(
                    calendarId=calendar_id,
                    timeMin=time_min.isoformat() + "Z",
                    timeMax=time_max.isoformat() + "Z",
                    singleEvents=True,
                    orderBy="startTime",
                )
                .execute()
            )

            events = events_result.get("items", [])

            # イベントを正規化
            normalized_events = [
                self._normalize_event(event) for event in events if event.get("status") != "cancelled"
            ]

            # 統計情報を計算
            summary_stats = self._calculate_stats(normalized_events)

            # 正規化されたデータを構築
            data = {
                "date": target_date.strftime("%Y-%m-%d"),
                "timezone": str(time_min.tzinfo) if time_min.tzinfo else "UTC",
                "events": normalized_events,
                "summary_stats": summary_stats,
            }

            self.logger.info(f"{len(normalized_events)}件のイベントを取得")

            return self._build_success_response(data, fetched_at=datetime.now())

        except HttpError as e:
            self.logger.error(f"Google Calendar API エラー: {e}")
            return self._build_error_response(
                "API_ERROR", f"Google Calendar APIエラー: {e.resp.status}"
            )
        except Exception as e:
            self.logger.error(f"データ取得エラー: {e}", exc_info=True)
            return self._build_error_response(
                "FETCH_ERROR", f"データ取得に失敗しました: {str(e)}"
            )

    def _normalize_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        イベントを正規化

        Args:
            event: Googleカレンダーイベント

        Returns:
            正規化されたイベント
        """
        # 開始・終了時刻を取得
        start = event["start"].get("dateTime", event["start"].get("date"))
        end = event["end"].get("dateTime", event["end"].get("date"))

        # DateTimeオブジェクトに変換
        start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
        end_dt = datetime.fromisoformat(end.replace("Z", "+00:00"))

        # 継続時間を計算
        duration_minutes = int((end_dt - start_dt).total_seconds() / 60)

        # 場所情報を解析
        location_info = self._parse_location(event.get("location"), event.get("conferenceData"))

        # 自分が主催者かチェック
        is_organizer = event.get("organizer", {}).get("self", False)

        # 参加者の応答ステータスを取得
        my_response = "needsAction"
        for attendee in event.get("attendees", []):
            if attendee.get("self"):
                my_response = attendee.get("responseStatus", "needsAction")
                break

        # ビデオ通話リンクがあるかチェック
        has_video_call = bool(event.get("conferenceData") or event.get("hangoutLink"))

        # 外部ミーティングかチェック（組織外のドメイン）
        is_external_meeting = self._is_external_meeting(event.get("attendees", []))

        return {
            "id": event["id"],
            "title": event.get("summary", "(タイトルなし)"),
            "description": event.get("description", ""),
            "start_time": start_dt.strftime("%H:%M"),
            "end_time": end_dt.strftime("%H:%M"),
            "duration_minutes": duration_minutes,
            "location": location_info,
            "attendees_count": len(event.get("attendees", [])),
            "is_organizer": is_organizer,
            "my_response": my_response,
            "has_video_call": has_video_call,
            "is_external_meeting": is_external_meeting,
        }

    def _parse_location(
        self, location: Optional[str], conference_data: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        場所情報を解析

        Args:
            location: 場所文字列
            conference_data: 会議データ

        Returns:
            正規化された場所情報
        """
        # ビデオ会議の場合
        if conference_data:
            entry_points = conference_data.get("entryPoints", [])
            for entry in entry_points:
                if entry.get("entryPointType") == "video":
                    return {
                        "type": "virtual",
                        "name": conference_data.get("conferenceSolution", {}).get(
                            "name", "オンライン会議"
                        ),
                        "url": entry.get("uri"),
                    }

        # 物理的な場所の場合
        if location:
            return {
                "type": "physical",
                "name": location,
                "url": None,
            }

        # 場所未設定
        return {
            "type": "unspecified",
            "name": "未設定",
            "url": None,
        }

    def _is_external_meeting(self, attendees: List[Dict[str, Any]]) -> bool:
        """
        外部ミーティングかチェック

        Args:
            attendees: 参加者リスト

        Returns:
            外部ミーティングの場合 True
        """
        # TODO: 組織ドメインの判定ロジックを実装
        # とりあえず False を返す
        return False

    def _calculate_stats(self, events: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        統計情報を計算

        Args:
            events: イベントリスト

        Returns:
            統計情報
        """
        total_events = len(events)
        total_meeting_hours = sum(e["duration_minutes"] for e in events) / 60
        external_meetings = sum(1 for e in events if e["is_external_meeting"])
        video_calls = sum(1 for e in events if e["has_video_call"])

        # 最も忙しい時間帯を判定
        morning_count = sum(1 for e in events if int(e["start_time"].split(":")[0]) < 12)
        afternoon_count = total_events - morning_count

        busiest_period = "午前" if morning_count > afternoon_count else "午後"

        return {
            "total_events": total_events,
            "total_meeting_hours": round(total_meeting_hours, 1),
            "external_meetings": external_meetings,
            "video_calls": video_calls,
            "busiest_period": busiest_period,
        }

    def get_required_scopes(self) -> List[str]:
        """必要なGoogleスコープ"""
        return ["https://www.googleapis.com/auth/calendar.readonly"]

    def get_config_schema(self) -> Dict[str, Any]:
        """設定スキーマ"""
        return {
            "type": "object",
            "properties": {
                "enabled": {"type": "boolean", "default": True},
                "calendar_id": {
                    "type": "string",
                    "default": "primary",
                    "description": "カレンダーID",
                },
            },
            "required": [],
        }
