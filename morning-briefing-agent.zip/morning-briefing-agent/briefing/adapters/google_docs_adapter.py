"""
Google Docsアダプター
Google Docsから議事録を取得し、決定事項やアクションアイテムを抽出
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
import re
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from .base import BaseAdapter

logger = logging.getLogger("briefing.adapters.google_docs")


class GoogleDocsAdapter(BaseAdapter):
    """Google Docs データソースアダプター"""

    def __init__(self, config: Dict[str, Any] = None, credentials: Dict[str, Any] = None):
        super().__init__(config, credentials)
        self.docs_service = None
        self.drive_service = None

    @property
    def source_name(self) -> str:
        return "google_docs"

    @property
    def source_display_name(self) -> str:
        return "Google Docs"

    async def authenticate(self) -> bool:
        """
        Google Docs認証を実行

        Returns:
            認証成功の可否
        """
        try:
            # OAuth2認証情報を構築
            creds_info = {
                "token": self.credentials.get("refresh_token"),
                "refresh_token": self.credentials.get("refresh_token"),
                "token_uri": "https://oauth2.googleapis.com/token",
                "client_id": self.credentials.get("client_id"),
                "client_secret": self.credentials.get("client_secret"),
                "scopes": self.get_required_scopes(),
            }

            creds = Credentials.from_authorized_user_info(creds_info)

            # Docs & Drive APIクライアント作成
            self.docs_service = build("docs", "v1", credentials=creds)
            self.drive_service = build("drive", "v3", credentials=creds)

            # 認証テスト
            files = (
                self.drive_service.files().list(pageSize=1).execute()
            )

            self.logger.info("Google Docs/Drive認証成功")
            return True

        except Exception as e:
            self.logger.error(f"Google Docs認証エラー: {e}")
            return False

    async def fetch_data(
        self, target_date: datetime, config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Google Docsからデータを取得

        Args:
            target_date: 取得対象日
            config: 追加設定

        Returns:
            正規化されたデータ
        """
        if not self.docs_service or not self.drive_service:
            await self.authenticate()

        if not self.docs_service:
            return self._build_error_response(
                "AUTH_FAILED", "Google Docs認証に失敗しました", recoverable=True
            )

        try:
            folder_id = self.config.get("folder_id")
            if not folder_id:
                self.logger.warning("folder_idが設定されていません")
                return self._build_success_response(
                    {"meeting_notes": [], "summary_stats": {"documents_found": 0}}
                )

            # 最近更新された議事録を取得
            max_docs = self.config.get("max_documents", 10)
            modified_since = target_date - timedelta(days=1)

            # Driveから議事録ファイルを検索
            doc_files = await self._search_meeting_notes(
                folder_id, modified_since, max_docs
            )

            # 各ドキュメントから情報を抽出
            meeting_notes = []
            for doc_file in doc_files:
                note = await self._extract_meeting_note(doc_file)
                if note:
                    meeting_notes.append(note)

            # 統計情報を計算
            summary_stats = self._calculate_stats(meeting_notes)

            # 正規化されたデータを構築
            data = {
                "meeting_notes": meeting_notes,
                "summary_stats": summary_stats,
            }

            self.logger.info(f"{len(meeting_notes)}件の議事録を取得")

            return self._build_success_response(data, fetched_at=datetime.now())

        except HttpError as e:
            self.logger.error(f"Google Docs/Drive API エラー: {e}")
            return self._build_error_response(
                "API_ERROR", f"Google Docs APIエラー: {e.resp.status}"
            )
        except Exception as e:
            self.logger.error(f"データ取得エラー: {e}", exc_info=True)
            return self._build_error_response(
                "FETCH_ERROR", f"データ取得に失敗しました: {str(e)}"
            )

    async def _search_meeting_notes(
        self, folder_id: str, modified_since: datetime, max_results: int
    ) -> List[Dict[str, Any]]:
        """
        議事録ファイルを検索

        Args:
            folder_id: 検索対象フォルダID
            modified_since: 更新日時の下限
            max_results: 最大取得件数

        Returns:
            ファイルリスト
        """
        query = (
            f"'{folder_id}' in parents "
            f"and mimeType='application/vnd.google-apps.document' "
            f"and modifiedTime > '{modified_since.isoformat()}Z' "
            f"and trashed=false"
        )

        try:
            results = (
                self.drive_service.files()
                .list(
                    q=query,
                    orderBy="modifiedTime desc",
                    pageSize=max_results,
                    fields="files(id, name, modifiedTime, lastModifyingUser)",
                )
                .execute()
            )

            return results.get("files", [])

        except HttpError as e:
            self.logger.error(f"ファイル検索エラー: {e}")
            return []

    async def _extract_meeting_note(self, doc_file: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        議事録から情報を抽出

        Args:
            doc_file: Driveファイル情報

        Returns:
            抽出された議事録情報
        """
        try:
            # ドキュメントの内容を取得
            doc = (
                self.docs_service.documents()
                .get(documentId=doc_file["id"])
                .execute()
            )

            # テキストを抽出
            full_text = self._extract_text_from_doc(doc)

            # 決定事項を抽出
            decisions = self._extract_decisions(full_text)

            # アクションアイテムを抽出
            action_items = self._extract_action_items(full_text)

            # 参加者を抽出
            participants = self._extract_participants(full_text)

            # 議事録の日付を推測
            meeting_date = self._extract_meeting_date(doc_file["name"], full_text)

            return {
                "document_id": doc_file["id"],
                "title": doc_file["name"],
                "meeting_date": meeting_date,
                "last_modified": doc_file.get("modifiedTime", ""),
                "last_modified_by": doc_file.get("lastModifyingUser", {}).get("displayName", "不明"),
                "url": f"https://docs.google.com/document/d/{doc_file['id']}/edit",
                "extracted": {
                    "participants": participants,
                    "decisions": decisions,
                    "action_items": action_items,
                },
            }

        except HttpError as e:
            self.logger.error(f"ドキュメント取得エラー: {e}")
            return None

    def _extract_text_from_doc(self, doc: Dict[str, Any]) -> str:
        """
        Google Docsドキュメントからテキストを抽出

        Args:
            doc: Docsドキュメント

        Returns:
            抽出されたテキスト
        """
        content = doc.get("body", {}).get("content", [])
        text_parts = []

        for element in content:
            if "paragraph" in element:
                para_elements = element["paragraph"].get("elements", [])
                for para_elem in para_elements:
                    if "textRun" in para_elem:
                        text_parts.append(para_elem["textRun"]["content"])

        return "".join(text_parts)

    def _extract_decisions(self, text: str) -> List[str]:
        """
        決定事項を抽出

        Args:
            text: ドキュメントテキスト

        Returns:
            決定事項リスト
        """
        decisions = []

        # "決定事項" "Decision" などのヘッダーを探す
        patterns = [
            r"決定事項[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"Decision[s]?[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"決まったこと[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
        ]

        for pattern in patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE | re.DOTALL)
            for match in matches:
                section_text = match.group(1)
                # 箇条書きを抽出
                bullet_items = re.findall(r"[•・\-\*]\s*(.+)", section_text)
                decisions.extend([item.strip() for item in bullet_items if item.strip()])

        return decisions[:10]  # 最大10件

    def _extract_action_items(self, text: str) -> List[Dict[str, Any]]:
        """
        アクションアイテムを抽出

        Args:
            text: ドキュメントテキスト

        Returns:
            アクションアイテムリスト
        """
        action_items = []

        # "ネクストアクション" "TODO" "Action Items" などのヘッダーを探す
        patterns = [
            r"ネクストアクション[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"アクションアイテム[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"Action\s*Items?[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"TODO[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
        ]

        for pattern in patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE | re.DOTALL)
            for match in matches:
                section_text = match.group(1)
                # 箇条書きを抽出
                bullet_items = re.findall(r"[•・\-\*]\s*(.+)", section_text)

                for item in bullet_items:
                    if not item.strip():
                        continue

                    # 担当者を抽出（【田中】形式）
                    assignee_match = re.search(r"【(.+?)】", item)
                    assignee = assignee_match.group(1) if assignee_match else None

                    # 期限を抽出
                    due_date = self._extract_due_date(item)

                    # タスク内容を抽出
                    task = item
                    if assignee_match:
                        task = item.replace(assignee_match.group(0), "").strip()

                    # TODO: 自分のタスクかどうかを判定
                    is_my_task = False  # 実装が必要

                    action_items.append(
                        {
                            "assignee": assignee,
                            "task": task,
                            "due_date": due_date,
                            "is_my_task": is_my_task,
                        }
                    )

        return action_items[:20]  # 最大20件

    def _extract_participants(self, text: str) -> List[str]:
        """
        参加者を抽出

        Args:
            text: ドキュメントテキスト

        Returns:
            参加者リスト
        """
        # "参加者" ヘッダーを探す
        patterns = [
            r"参加者[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
            r"Attendees?[：:\s]*\n(.*?)(?=\n\n|\n[#＃]|$)",
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                participants_text = match.group(1)
                # カンマ区切りまたは改行区切りで分割
                names = re.split(r"[,、\n]", participants_text)
                return [name.strip() for name in names if name.strip()]

        return []

    def _extract_meeting_date(self, title: str, text: str) -> Optional[str]:
        """
        議事録の日付を抽出

        Args:
            title: ドキュメントタイトル
            text: ドキュメントテキスト

        Returns:
            日付（YYYY-MM-DD形式）
        """
        # タイトルから日付を抽出
        date_patterns = [
            r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})",
            r"(\d{4})(\d{2})(\d{2})",
        ]

        for pattern in date_patterns:
            match = re.search(pattern, title)
            if match:
                year, month, day = match.groups()
                return f"{year}-{month.zfill(2)}-{day.zfill(2)}"

        # テキストから日付を抽出
        for pattern in date_patterns:
            match = re.search(pattern, text[:200])  # 先頭200文字のみ
            if match:
                year, month, day = match.groups()
                return f"{year}-{month.zfill(2)}-{day.zfill(2)}"

        return None

    def _extract_due_date(self, text: str) -> Optional[str]:
        """
        期限を抽出

        Args:
            text: テキスト

        Returns:
            期限（YYYY-MM-DD形式）
        """
        # 日付パターンを探す
        patterns = [
            r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})",
            r"(\d{1,2})[/月](\d{1,2})",  # MM/DD形式
        ]

        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                groups = match.groups()
                if len(groups) == 3:
                    year, month, day = groups
                    return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
                elif len(groups) == 2:
                    # 年を現在年と仮定
                    month, day = groups
                    current_year = datetime.now().year
                    return f"{current_year}-{month.zfill(2)}-{day.zfill(2)}"

        return None

    def _calculate_stats(self, meeting_notes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        統計情報を計算

        Args:
            meeting_notes: 議事録リスト

        Returns:
            統計情報
        """
        documents_found = len(meeting_notes)
        total_decisions = sum(
            len(note["extracted"]["decisions"]) for note in meeting_notes
        )
        total_action_items = sum(
            len(note["extracted"]["action_items"]) for note in meeting_notes
        )
        my_action_items = sum(
            sum(1 for item in note["extracted"]["action_items"] if item["is_my_task"])
            for note in meeting_notes
        )

        return {
            "documents_found": documents_found,
            "total_decisions": total_decisions,
            "total_action_items": total_action_items,
            "my_action_items": my_action_items,
        }

    def get_required_scopes(self) -> List[str]:
        """必要なGoogleスコープ"""
        return [
            "https://www.googleapis.com/auth/documents.readonly",
            "https://www.googleapis.com/auth/drive.readonly",
        ]

    def get_config_schema(self) -> Dict[str, Any]:
        """設定スキーマ"""
        return {
            "type": "object",
            "properties": {
                "enabled": {"type": "boolean", "default": True},
                "folder_id": {
                    "type": "string",
                    "description": "議事録が保存されているフォルダID",
                },
                "max_documents": {
                    "type": "integer",
                    "default": 10,
                    "description": "取得する議事録の最大件数",
                },
            },
            "required": ["folder_id"],
        }
