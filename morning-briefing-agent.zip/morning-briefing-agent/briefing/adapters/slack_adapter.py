"""
Slackアダプター
Slackからメッセージ履歴、メンション、リアクションなどを取得
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

from .base import BaseAdapter

logger = logging.getLogger("briefing.adapters.slack")


class SlackAdapter(BaseAdapter):
    """Slack データソースアダプター"""

    def __init__(self, config: Dict[str, Any] = None, credentials: Dict[str, Any] = None):
        super().__init__(config, credentials)
        self.client: Optional[WebClient] = None
        self.bot_user_id: Optional[str] = None

    @property
    def source_name(self) -> str:
        return "slack"

    @property
    def source_display_name(self) -> str:
        return "Slack"

    async def authenticate(self) -> bool:
        """
        Slack認証を実行

        Returns:
            認証成功の可否
        """
        try:
            token = self.credentials.get("bot_token")
            if not token:
                self.logger.error("Slack Bot Tokenが設定されていません")
                return False

            self.client = WebClient(token=token)

            # 認証テスト
            response = self.client.auth_test()
            self.bot_user_id = response["user_id"]

            self.logger.info(
                f"Slack認証成功: {response['team']} / {response['user']}"
            )
            return True

        except SlackApiError as e:
            self.logger.error(f"Slack認証エラー: {e.response['error']}")
            return False
        except Exception as e:
            self.logger.error(f"予期しないエラー: {e}")
            return False

    async def fetch_data(
        self, target_date: datetime, config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Slackからデータを取得

        Args:
            target_date: 取得対象日
            config: 追加設定

        Returns:
            正規化されたデータ
        """
        if not self.client:
            await self.authenticate()

        if not self.client:
            return self._build_error_response(
                "AUTH_FAILED", "Slack認証に失敗しました", recoverable=True
            )

        try:
            # 取得期間の計算
            history_hours = self.config.get("history_hours", 24)
            oldest = target_date - timedelta(hours=history_hours)
            latest = target_date

            # データ収集
            channel_history = await self._fetch_channel_history(oldest, latest)
            pending_mentions = await self._fetch_pending_mentions()
            summary_stats = self._calculate_stats(channel_history, pending_mentions)

            # 正規化されたデータを構築
            data = {
                "channel_history": channel_history,
                "pending_mentions": pending_mentions,
                "summary_stats": summary_stats,
            }

            return self._build_success_response(data, fetched_at=datetime.now())

        except Exception as e:
            self.logger.error(f"データ取得エラー: {e}", exc_info=True)
            return self._build_error_response(
                "FETCH_ERROR", f"データ取得に失敗しました: {str(e)}"
            )

    async def _fetch_channel_history(
        self, oldest: datetime, latest: datetime
    ) -> List[Dict[str, Any]]:
        """
        チャンネル履歴を取得

        Args:
            oldest: 取得開始日時
            latest: 取得終了日時

        Returns:
            正規化されたメッセージリスト
        """
        channels = self.config.get("channels", [])
        exclude_bots = self.config.get("exclude_bots", True)

        channel_data = []

        for channel_name in channels:
            try:
                # チャンネルIDを取得
                channel_id = await self._get_channel_id(channel_name)
                if not channel_id:
                    self.logger.warning(f"チャンネルが見つかりません: {channel_name}")
                    continue

                # メッセージ履歴を取得
                response = self.client.conversations_history(
                    channel=channel_id,
                    oldest=str(int(oldest.timestamp())),
                    latest=str(int(latest.timestamp())),
                    limit=100,
                )

                messages = []
                for msg in response.get("messages", []):
                    # Bot除外（設定による）
                    if exclude_bots and msg.get("subtype") == "bot_message":
                        continue

                    # メッセージを正規化
                    normalized_msg = await self._normalize_message(msg, channel_name)
                    messages.append(normalized_msg)

                channel_data.append(
                    {
                        "channel_id": channel_id,
                        "channel_name": channel_name,
                        "messages": messages,
                    }
                )

                self.logger.info(
                    f"チャンネル {channel_name}: {len(messages)}件のメッセージを取得"
                )

            except SlackApiError as e:
                self.logger.error(f"チャンネル {channel_name} の取得エラー: {e}")
                continue

        return channel_data

    async def _fetch_pending_mentions(self) -> List[Dict[str, Any]]:
        """
        未対応のメンションを取得

        Returns:
            未対応メンションリスト
        """
        pending = []

        try:
            # 自分宛メンションを検索
            response = self.client.search_messages(
                query=f"<@{self.bot_user_id}>",
                sort="timestamp",
                sort_dir="desc",
                count=50,
            )

            for match in response.get("messages", {}).get("matches", []):
                # 未返信・未リアクションをチェック
                has_my_reply = self._has_my_reply(match)
                has_my_reaction = self._has_my_reaction(match)

                if not has_my_reply and not has_my_reaction:
                    # ユーザー情報を取得
                    author_info = await self._get_user_info(match.get("user"))

                    # 経過時間を計算
                    msg_time = datetime.fromtimestamp(float(match["ts"]))
                    hours_since = (datetime.now() - msg_time).total_seconds() / 3600

                    # 優先度スコアを計算
                    priority_score = self._calculate_mention_priority(
                        hours_since, match.get("channel", {}).get("is_im", False)
                    )

                    pending.append(
                        {
                            "id": match["ts"],
                            "channel_name": match.get("channel", {}).get("name", "DM"),
                            "author_name": author_info.get("real_name", "不明"),
                            "content": match.get("text", ""),
                            "timestamp": msg_time.isoformat(),
                            "hours_since_posted": round(hours_since, 1),
                            "priority_score": priority_score,
                            "permalink": match.get("permalink", ""),
                        }
                    )

            self.logger.info(f"{len(pending)}件の未対応メンションを検出")

        except SlackApiError as e:
            self.logger.error(f"メンション検索エラー: {e}")

        return pending

    async def _get_channel_id(self, channel_name: str) -> Optional[str]:
        """
        チャンネル名からチャンネルIDを取得

        Args:
            channel_name: チャンネル名（#なし）

        Returns:
            チャンネルID
        """
        channel_name = channel_name.lstrip("#")

        try:
            # パブリックチャンネルを検索
            response = self.client.conversations_list(types="public_channel,private_channel")
            for channel in response.get("channels", []):
                if channel["name"] == channel_name:
                    return channel["id"]

        except SlackApiError as e:
            self.logger.error(f"チャンネルID取得エラー: {e}")

        return None

    async def _get_user_info(self, user_id: str) -> Dict[str, Any]:
        """
        ユーザー情報を取得

        Args:
            user_id: ユーザーID

        Returns:
            ユーザー情報
        """
        try:
            response = self.client.users_info(user=user_id)
            user = response["user"]
            return {
                "id": user["id"],
                "name": user.get("name", ""),
                "real_name": user.get("real_name", ""),
                "display_name": user.get("profile", {}).get("display_name", ""),
            }
        except SlackApiError:
            return {"id": user_id, "name": "不明", "real_name": "不明"}

    async def _normalize_message(
        self, msg: Dict[str, Any], channel_name: str
    ) -> Dict[str, Any]:
        """
        メッセージを正規化

        Args:
            msg: Slackメッセージ
            channel_name: チャンネル名

        Returns:
            正規化されたメッセージ
        """
        # ユーザー情報を取得
        author_info = await self._get_user_info(msg.get("user", ""))

        # タイムスタンプを変換
        timestamp = datetime.fromtimestamp(float(msg["ts"]))

        # メンションチェック
        mentions_me = self.bot_user_id and f"<@{self.bot_user_id}>" in msg.get("text", "")

        return {
            "id": msg["ts"],
            "author": author_info,
            "content": msg.get("text", ""),
            "timestamp": timestamp.isoformat(),
            "mentions_me": mentions_me,
            "is_thread_reply": "thread_ts" in msg and msg["thread_ts"] != msg["ts"],
            "reaction_count": len(msg.get("reactions", [])),
            "has_my_reaction": self._has_my_reaction(msg),
            "has_my_reply": False,  # TODO: スレッド返信チェック
            "attachments": [
                att.get("title", att.get("fallback", ""))
                for att in msg.get("attachments", [])
            ],
            "permalink": f"https://slack.com/archives/{channel_name}/p{msg['ts'].replace('.', '')}",
        }

    def _has_my_reply(self, msg: Dict[str, Any]) -> bool:
        """自分が返信しているかチェック"""
        # TODO: スレッド返信の実装
        return False

    def _has_my_reaction(self, msg: Dict[str, Any]) -> bool:
        """自分がリアクションしているかチェック"""
        if not self.bot_user_id:
            return False

        for reaction in msg.get("reactions", []):
            if self.bot_user_id in reaction.get("users", []):
                return True

        return False

    def _calculate_mention_priority(self, hours_since: float, is_dm: bool) -> int:
        """
        メンションの優先度スコアを計算

        Args:
            hours_since: 経過時間（時間）
            is_dm: DMかどうか

        Returns:
            優先度スコア
        """
        # 基本スコア
        score = 30 if is_dm else 20

        # 経過時間による加算
        if hours_since > 24:
            score += int((hours_since / 24) * 20)

        return min(score, 100)  # 最大100点

    def _calculate_stats(
        self, channel_history: List[Dict], pending_mentions: List[Dict]
    ) -> Dict[str, Any]:
        """
        統計情報を計算

        Args:
            channel_history: チャンネル履歴
            pending_mentions: 未対応メンション

        Returns:
            統計情報
        """
        total_messages = sum(len(ch["messages"]) for ch in channel_history)
        channels_active = len(channel_history)
        mentions_pending = len(pending_mentions)

        # 緊急キーワードを検出
        urgent_keywords = ["緊急", "urgent", "ASAP", "至急"]
        keywords_found = []

        for ch in channel_history:
            for msg in ch["messages"]:
                content = msg.get("content", "").lower()
                for keyword in urgent_keywords:
                    if keyword.lower() in content and keyword not in keywords_found:
                        keywords_found.append(keyword)

        return {
            "total_messages": total_messages,
            "channels_active": channels_active,
            "mentions_pending": mentions_pending,
            "keywords_found": keywords_found,
        }

    def get_required_scopes(self) -> List[str]:
        """必要なSlackスコープ"""
        return [
            "channels:history",
            "channels:read",
            "groups:history",
            "groups:read",
            "im:history",
            "im:read",
            "mpim:history",
            "users:read",
            "search:read",
        ]

    def get_config_schema(self) -> Dict[str, Any]:
        """設定スキーマ"""
        return {
            "type": "object",
            "properties": {
                "enabled": {"type": "boolean", "default": True},
                "channels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "監視するチャンネル名のリスト",
                },
                "delivery_channel": {
                    "type": "string",
                    "description": "配信先チャンネルまたはDM",
                },
                "history_hours": {
                    "type": "integer",
                    "default": 24,
                    "description": "取得する履歴の時間数",
                },
                "exclude_bots": {
                    "type": "boolean",
                    "default": True,
                    "description": "Botメッセージを除外するか",
                },
            },
            "required": ["channels", "delivery_channel"],
        }
