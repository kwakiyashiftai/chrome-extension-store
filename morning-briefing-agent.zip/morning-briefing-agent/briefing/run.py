"""
モーニング・ブリーフィング・エージェント - メインスクリプト
"""

import asyncio
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

from briefing import setup_logging, PACKAGE_ROOT
from briefing.core.config import get_config
from briefing.adapters import AVAILABLE_ADAPTERS
from briefing.core.aggregator import aggregate_data
from briefing.core.priority import calculate_all_priorities
from briefing.agent.mistral_agent import MorningBriefingAgent
from briefing.output.slack_sender import SlackSender
from briefing.output.tts import generate_voice

logger = logging.getLogger("briefing.run")


class BriefingRunner:
    """ブリーフィング実行クラス"""

    def __init__(self, config_dir: Path = None):
        """
        Args:
            config_dir: 設定ディレクトリ
        """
        # 設定を読み込み
        self.config = get_config(config_dir)

        # ロギングをセットアップ
        log_file = self.config.get_log_file_path()
        setup_logging(self.config.logging.level, str(log_file))

        logger.info("=== モーニング・ブリーフィング・エージェント起動 ===")

        # 設定の妥当性チェック
        errors = self.config.validate()
        if errors:
            for error in errors:
                logger.error(f"設定エラー: {error}")
            raise ValueError("設定に問題があります")

    async def run(self, target_date: datetime = None, preview: bool = False):
        """
        ブリーフィングを実行

        Args:
            target_date: 対象日（デフォルト: 今日）
            preview: プレビューモード（配信なし）
        """
        try:
            target_date = target_date or datetime.now()
            logger.info(f"対象日: {target_date.strftime('%Y-%m-%d')}")

            # Step 1: データ収集
            logger.info("=== Step 1: データ収集 ===")
            raw_data = await self._collect_data(target_date)

            # Step 2: データ統合
            logger.info("=== Step 2: データ統合 ===")
            aggregated_data = aggregate_data(raw_data)

            # Step 3: 優先度計算
            logger.info("=== Step 3: 優先度計算 ===")
            aggregated_data = calculate_all_priorities(
                aggregated_data, self.config.priority.__dict__
            )

            # Step 4: ブリーフィング生成
            logger.info("=== Step 4: ブリーフィング生成 ===")
            agent = MorningBriefingAgent(
                agent_id=self.config.agent.id,
                api_key=self.config.credentials.mistral_api_key,
            )
            briefing = agent.generate_briefing(aggregated_data)

            logger.info(f"テキストブリーフィング: {len(briefing['text'])}文字")
            logger.info(f"音声スクリプト: {len(briefing['voice_script'])}文字")

            # Step 5: 音声生成（設定による）
            voice_file_path = None
            if self.config.output.include_voice:
                logger.info("=== Step 5: 音声生成 ===")
                voice_file_path = str(PACKAGE_ROOT / "output" / f"briefing_{target_date.strftime('%Y%m%d')}.mp3")

                # 出力ディレクトリを作成
                Path(voice_file_path).parent.mkdir(exist_ok=True)

                success = generate_voice(
                    text=briefing["voice_script"],
                    output_path=voice_file_path,
                    provider="gtts",
                    language=self.config.output.language,
                )

                if success:
                    logger.info(f"音声ファイル生成完了: {voice_file_path}")
                else:
                    logger.warning("音声ファイル生成失敗")
                    voice_file_path = None

            # Step 6: Slack配信（プレビューモードでない場合）
            if not preview:
                logger.info("=== Step 6: Slack配信 ===")
                sender = SlackSender(self.config.credentials.slack_bot_token)

                delivery_channel = self.config.data_sources.slack.delivery_channel
                success = sender.send_briefing(
                    channel=delivery_channel,
                    text=briefing["text"],
                    voice_file_path=voice_file_path,
                )

                if success:
                    logger.info(f"ブリーフィング配信完了: {delivery_channel}")
                else:
                    logger.error("ブリーフィング配信失敗")

            else:
                logger.info("=== プレビューモード: 配信をスキップ ===")
                print("\n" + "=" * 80)
                print(briefing["text"])
                print("=" * 80 + "\n")

            # Step 7: 会話削除（プライバシー対応）
            if self.config.output.delete_conversation:
                agent.delete_conversation()

            logger.info("=== 処理完了 ===")

        except Exception as e:
            logger.error(f"実行エラー: {e}", exc_info=True)

            # エラー通知
            if not preview:
                try:
                    sender = SlackSender(self.config.credentials.slack_bot_token)
                    sender.send_error_notification(
                        channel=self.config.data_sources.slack.delivery_channel,
                        error_message=str(e),
                    )
                except Exception:
                    pass

            raise

    async def _collect_data(self, target_date: datetime) -> Dict[str, Any]:
        """
        各データソースからデータを収集

        Args:
            target_date: 対象日

        Returns:
            収集されたデータ
        """
        raw_data = {}

        # 有効なアダプターを初期化して実行
        tasks = []

        # Slack
        if self.config.data_sources.slack.enabled:
            adapter_class = AVAILABLE_ADAPTERS.get("slack")
            adapter = adapter_class(
                config=self.config.data_sources.slack.__dict__,
                credentials={
                    "bot_token": self.config.credentials.slack_bot_token,
                },
            )
            tasks.append(("slack", adapter.fetch_data(target_date)))

        # Google Calendar
        if self.config.data_sources.google_calendar.enabled:
            adapter_class = AVAILABLE_ADAPTERS.get("google_calendar")
            adapter = adapter_class(
                config=self.config.data_sources.google_calendar.__dict__,
                credentials={
                    "client_id": self.config.credentials.google_client_id,
                    "client_secret": self.config.credentials.google_client_secret,
                    "refresh_token": self.config.credentials.google_refresh_token,
                },
            )
            tasks.append(("google_calendar", adapter.fetch_data(target_date)))

        # Google Docs
        if self.config.data_sources.google_docs.enabled:
            adapter_class = AVAILABLE_ADAPTERS.get("google_docs")
            adapter = adapter_class(
                config=self.config.data_sources.google_docs.__dict__,
                credentials={
                    "client_id": self.config.credentials.google_client_id,
                    "client_secret": self.config.credentials.google_client_secret,
                    "refresh_token": self.config.credentials.google_refresh_token,
                },
            )
            tasks.append(("google_docs", adapter.fetch_data(target_date)))

        # 並列で実行
        results = await asyncio.gather(*[task[1] for task in tasks])

        # 結果を格納
        for (source_name, _), result in zip(tasks, results):
            raw_data[source_name] = result
            status = result.get("status", "unknown")
            logger.info(f"{source_name}: {status}")

        return raw_data


def main():
    """メイン関数"""
    import argparse

    parser = argparse.ArgumentParser(
        description="モーニング・ブリーフィング・エージェント"
    )
    parser.add_argument(
        "--preview",
        action="store_true",
        help="プレビューモード（配信なし）",
    )
    parser.add_argument(
        "--date",
        type=str,
        help="対象日（YYYY-MM-DD形式）",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="デバッグモード",
    )
    parser.add_argument(
        "--now",
        action="store_true",
        help="即座に実行（配信あり）",
    )

    args = parser.parse_args()

    # 対象日を設定
    target_date = None
    if args.date:
        target_date = datetime.strptime(args.date, "%Y-%m-%d")

    # デバッグモード
    if args.debug:
        logging.basicConfig(level=logging.DEBUG)

    # 実行
    runner = BriefingRunner()

    # プレビューモードまたは即座に実行
    preview = args.preview or not args.now

    try:
        asyncio.run(runner.run(target_date=target_date, preview=preview))
        sys.exit(0)
    except KeyboardInterrupt:
        logger.info("ユーザーによって中断されました")
        sys.exit(1)
    except Exception as e:
        logger.error(f"実行失敗: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
