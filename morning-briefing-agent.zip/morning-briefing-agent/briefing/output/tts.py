"""
TTS（Text-to-Speech）モジュール
テキストから音声ファイルを生成
"""

import logging
from pathlib import Path
from typing import Optional
from gtts import gTTS

logger = logging.getLogger("briefing.output.tts")


class TTSGenerator:
    """TTS音声生成クラス"""

    def __init__(self, provider: str = "gtts", language: str = "ja"):
        """
        Args:
            provider: TTSプロバイダー ("gtts", "google_cloud", "openai")
            language: 言語コード
        """
        self.provider = provider
        self.language = language
        logger.info(f"TTSGenerator初期化: {provider} ({language})")

    def generate(
        self,
        text: str,
        output_path: str,
    ) -> bool:
        """
        音声ファイルを生成

        Args:
            text: 読み上げテキスト
            output_path: 出力ファイルパス（.mp3）

        Returns:
            生成成功の可否
        """
        try:
            logger.info(f"音声生成開始: {len(text)}文字")

            if self.provider == "gtts":
                return self._generate_gtts(text, output_path)
            else:
                raise ValueError(f"未対応のTTSプロバイダー: {self.provider}")

        except Exception as e:
            logger.error(f"音声生成エラー: {e}", exc_info=True)
            return False

    def _generate_gtts(self, text: str, output_path: str) -> bool:
        """
        gTTSで音声を生成

        Args:
            text: テキスト
            output_path: 出力パス

        Returns:
            成功の可否
        """
        try:
            # gTTSで音声を生成
            tts = gTTS(text=text, lang=self.language, slow=False)

            # ファイルに保存
            tts.save(output_path)

            logger.info(f"音声ファイル生成完了: {output_path}")
            return True

        except Exception as e:
            logger.error(f"gTTS生成エラー: {e}")
            return False


# Google Cloud TTS版（オプション）
class GoogleCloudTTSGenerator:
    """Google Cloud TTS音声生成クラス"""

    def __init__(self, language: str = "ja-JP"):
        """
        Args:
            language: 言語コード
        """
        try:
            from google.cloud import texttospeech

            self.client = texttospeech.TextToSpeechClient()
            self.language = language
            logger.info(f"Google Cloud TTS初期化: {language}")

        except ImportError:
            logger.error("google-cloud-texttospeech がインストールされていません")
            raise

    def generate(self, text: str, output_path: str) -> bool:
        """
        音声ファイルを生成

        Args:
            text: 読み上げテキスト
            output_path: 出力ファイルパス

        Returns:
            生成成功の可否
        """
        try:
            from google.cloud import texttospeech

            # 入力テキストを設定
            synthesis_input = texttospeech.SynthesisInput(text=text)

            # 音声設定
            voice = texttospeech.VoiceSelectionParams(
                language_code=self.language,
                name=f"{self.language}-Neural2-C",  # 女性の声
            )

            # オーディオ設定
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.MP3,
                speaking_rate=1.0,  # 話す速度
                pitch=0.0,  # ピッチ
            )

            # 音声を合成
            response = self.client.synthesize_speech(
                input=synthesis_input, voice=voice, audio_config=audio_config
            )

            # ファイルに保存
            with open(output_path, "wb") as out:
                out.write(response.audio_content)

            logger.info(f"Google Cloud TTS音声生成完了: {output_path}")
            return True

        except Exception as e:
            logger.error(f"Google Cloud TTS生成エラー: {e}", exc_info=True)
            return False


# ヘルパー関数
def generate_voice(
    text: str,
    output_path: str,
    provider: str = "gtts",
    language: str = "ja",
) -> bool:
    """
    音声ファイルを生成（ヘルパー関数）

    Args:
        text: テキスト
        output_path: 出力パス
        provider: TTSプロバイダー
        language: 言語

    Returns:
        成功の可否
    """
    if provider == "google_cloud":
        generator = GoogleCloudTTSGenerator(language=language)
    else:
        generator = TTSGenerator(provider=provider, language=language)

    return generator.generate(text, output_path)


# テスト用
if __name__ == "__main__":
    test_text = """
おはようございます。
1月12日、日曜日のブリーフィングです。

今日は特に大きな動きがありませんでした。
ゆっくりとした一日をお過ごしください。

以上です。
本日も良い一日をお過ごしください。
"""

    output_path = "/tmp/test_briefing.mp3"

    # gTTSでテスト
    success = generate_voice(test_text, output_path, provider="gtts")

    if success:
        print(f"音声ファイル生成成功: {output_path}")
    else:
        print("音声ファイル生成失敗")
