"""
プロンプトテンプレート
ブリーフィング生成とFor音声スクリプト生成用のプロンプト
"""

from datetime import datetime
from typing import Dict, Any
import json


# システムプロンプト（テキスト要約用）
SYSTEM_PROMPT_TEXT = """あなたは優秀なビジネスアシスタントです。
ユーザーの業務情報を分析し、朝のブリーフィングを作成します。

## 出力ルール
- 簡潔で要点を押さえた日本語で書く
- 重要度の高い項目から順に記載
- 箇条書きを活用し、読みやすく整形
- 推測や補足は入れず、与えられた情報のみを要約
- 固有名詞（人名、プロジェクト名）はそのまま使用
- データがないセクションは「特になし」と記載

## 制限
- 「要対応」: 最大5件
- 「昨日の振り返り」: 最大5件
- 「今日のToDo」: 最大10件
"""


# ユーザープロンプト（テキスト要約用）
def build_text_prompt(date: str, data: Dict[str, Any]) -> str:
    """
    テキスト要約用のプロンプトを構築

    Args:
        date: 日付（例: "2025年1月11日（土）"）
        data: 統合データ

    Returns:
        プロンプト文字列
    """
    return f"""以下の業務データを基に、朝のブリーフィングを作成してください。

## 入力データ
```json
{json.dumps(data, ensure_ascii=False, indent=2)}
```

## 出力フォーマット（このまま使用）

🌅 **{date} Morning Briefing**

---

**🔴 要対応**
• [箇条書きで記載。形式: 【ソース】誰より：内容（経過時間・チャンネル名）]

---

**📋 昨日の振り返り**
• [箇条書きで記載]

---

**📅 本日のスケジュール**
| 時間 | 予定 | 場所 |
|-----|------|------|
| [HH:MM-HH:MM] | [予定名] | [場所/URL] |

---

**✅ 今日のToDo**
• [ ] [タスク名]（[締切があれば記載]）

---

## 注意事項
- 「要対応」には priority_score が50以上の項目のみ記載
- データがないセクションは「特になし」と記載
- 会議URLは省略せずそのまま記載
"""


# システムプロンプト（音声スクリプト用）
SYSTEM_PROMPT_VOICE = """あなたはラジオのニュースキャスターです。
ビジネスパーソン向けの朝のブリーフィングを読み上げます。

## 話し方のルール
- 自然で聞き取りやすい日本語
- 数字は読み仮名で（例: 10 → じゅう、20% → にじゅっパーセント）
- URLは「ズームのリンク」「会議リンク」のように省略
- 時刻は「じゅうじ」「じゅうごじ」と読む
- 句読点で適切に区切る
- 1文は40文字以内を目安に
- 全体で3分程度の長さに
"""


# ユーザープロンプト（音声スクリプト用）
def build_voice_prompt(data: Dict[str, Any]) -> str:
    """
    音声スクリプト用のプロンプトを構築

    Args:
        data: 統合データ

    Returns:
        プロンプト文字列
    """
    return f"""以下のブリーフィングデータを、音声読み上げ用のスクリプトに変換してください。

## 入力データ
```json
{json.dumps(data, ensure_ascii=False, indent=2)}
```

## 構成（この順序で）
1. 挨拶と日付
2. 要対応事項（最重要、あれば）
3. 昨日のハイライト（あれば）
4. 今日のスケジュール
5. 今日のタスク
6. 締めの挨拶

## 注意
- 各段落は改行で区切る
- 「えー」「あー」などは入れない
- データがない場合はそのセクションを省略
"""


# 簡易版プロンプト（データが空の場合）
def build_empty_prompt(date: str) -> str:
    """
    データが空の場合のプロンプト

    Args:
        date: 日付

    Returns:
        プロンプト文字列
    """
    return f"""以下の{date}のブリーフィングを作成してください。

今日は特に大きな動きがありませんでした。
ゆっくりとした一日をお過ごしください。

## 出力フォーマット

🌅 **{date} Morning Briefing**

---

**🔴 要対応**
特になし

---

**📋 昨日の振り返り**
特に大きな動きはありませんでした。

---

**📅 本日のスケジュール**
予定はありません。ゆっくりお過ごしください。

---

**✅ 今日のToDo**
登録されているタスクはありません。

---
"""


def format_date_japanese(date: datetime) -> str:
    """
    日付を日本語形式にフォーマット

    Args:
        date: 日付

    Returns:
        日本語形式の日付（例: "2025年1月11日（土）"）
    """
    weekdays = ["月", "火", "水", "木", "金", "土", "日"]
    weekday = weekdays[date.weekday()]
    return f"{date.year}年{date.month}月{date.day}日（{weekday}）"


# プロンプトバリデーション
def validate_data(data: Dict[str, Any]) -> bool:
    """
    入力データの妥当性をチェック

    Args:
        data: 統合データ

    Returns:
        データが有効な場合 True
    """
    # 必須フィールドのチェック
    required_fields = ["date", "urgent_items", "yesterday_highlights", "today_schedule", "today_tasks"]

    for field in required_fields:
        if field not in data:
            return False

    return True


# テストデータ
SAMPLE_DATA = {
    "date": "2025年1月12日（日）",
    "urgent_items": [
        {
            "source": "slack",
            "summary": "ロゴ修正案の確認依頼",
            "author": "鈴木",
            "channel": "project-a",
            "hours_since": 18,
            "priority_score": 50,
        }
    ],
    "yesterday_highlights": [
        {"source": "slack", "summary": "プロジェクトBの進捗について合意形成"},
        {"source": "google_docs", "summary": "次期フェーズの予算を20%増額で決定"},
    ],
    "today_schedule": [
        {"time": "10:00-11:00", "title": "内部MTG", "location": "会議室A"},
        {
            "time": "15:00-16:00",
            "title": "クライアント商談",
            "location": "https://zoom.us/j/123456",
        },
    ],
    "today_tasks": [
        {"title": "報告書の提出", "due_time": "18:00", "priority": "urgent"},
        {"title": "デザインレビュー", "due_time": None, "priority": "high"},
    ],
}
