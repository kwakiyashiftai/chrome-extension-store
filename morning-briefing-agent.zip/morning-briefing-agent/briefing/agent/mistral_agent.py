"""
Mistral Agent統合モジュール
Mistral Agent APIを使用してブリーフィングと音声スクリプトを生成
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from mistralai import Mistral

from . import prompts

logger = logging.getLogger("briefing.agent.mistral")


class MorningBriefingAgent:
    """モーニングブリーフィングエージェント"""

    def __init__(self, agent_id: str = None, api_key: str = None):
        """
        Args:
            agent_id: Mistral Agent ID
            api_key: Mistral API Key
        """
        self.agent_id = agent_id or os.environ.get("BRIEFING_AGENT_ID")
        api_key = api_key or os.environ.get("MISTRAL_API_KEY")

        if not api_key:
            raise ValueError("Mistral API Keyが設定されていません")

        self.client = Mistral(api_key=api_key)
        self.conversation_id: Optional[str] = None

        logger.info(f"MorningBriefingAgent初期化完了 (agent_id={self.agent_id})")

    def generate_briefing(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        ブリーフィングを生成

        Args:
            data: 統合データ

        Returns:
            {
                "text": str,           # Markdown形式のブリーフィング
                "voice_script": str,   # 音声用スクリプト
                "conversation_id": str # 会話ID（継続用）
            }
        """
        try:
            logger.info("ブリーフィング生成開始")

            # 日付のフォーマット
            today = prompts.format_date_japanese(datetime.now())

            # Step 1: テキストブリーフィング生成
            logger.info("テキストブリーフィング生成中...")
            text_prompt = prompts.build_text_prompt(today, data)
            text_response = self._call_agent(text_prompt)

            briefing_text = self._extract_content(text_response)
            self.conversation_id = getattr(text_response, "conversation_id", None)

            logger.info(f"テキストブリーフィング生成完了 ({len(briefing_text)}文字)")

            # Step 2: 音声スクリプト生成（同じ会話を継続）
            logger.info("音声スクリプト生成中...")
            voice_prompt = prompts.build_voice_prompt(data)

            if self.conversation_id:
                voice_response = self._continue_conversation(voice_prompt)
            else:
                voice_response = self._call_agent(voice_prompt)

            voice_script = self._extract_content(voice_response)

            logger.info(f"音声スクリプト生成完了 ({len(voice_script)}文字)")

            return {
                "text": briefing_text,
                "voice_script": voice_script,
                "conversation_id": self.conversation_id,
            }

        except Exception as e:
            logger.error(f"ブリーフィング生成エラー: {e}", exc_info=True)
            raise

    def _call_agent(self, prompt: str) -> Any:
        """
        Agentを呼び出し（新しい会話を開始）

        Args:
            prompt: プロンプト

        Returns:
            APIレスポンス
        """
        if self.agent_id:
            # Agent IDが指定されている場合
            response = self.client.beta.conversations.start(
                agent_id=self.agent_id,
                inputs=[{"role": "user", "content": prompt}],
            )
        else:
            # Agent IDがない場合は通常のChat Completion
            response = self.client.chat.complete(
                model="mistral-medium-2505",
                messages=[
                    {"role": "system", "content": prompts.SYSTEM_PROMPT_TEXT},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=2000,
            )

        return response

    def _continue_conversation(self, prompt: str) -> Any:
        """
        会話を継続

        Args:
            prompt: プロンプト

        Returns:
            APIレスポンス
        """
        if not self.conversation_id:
            logger.warning("conversation_idがありません。新しい会話を開始します。")
            return self._call_agent(prompt)

        response = self.client.beta.conversations.append(
            conversation_id=self.conversation_id,
            inputs=[{"role": "user", "content": prompt}],
        )

        return response

    def _extract_content(self, response: Any) -> str:
        """
        レスポンスからコンテンツを抽出

        Args:
            response: APIレスポンス

        Returns:
            抽出されたテキスト
        """
        try:
            # Agent APIの場合
            if hasattr(response, "outputs"):
                for entry in response.outputs:
                    if hasattr(entry, "content"):
                        content = entry.content
                        if isinstance(content, str):
                            return content
                        elif isinstance(content, list):
                            # TextChunkの場合
                            return "".join(
                                [
                                    chunk.text
                                    for chunk in content
                                    if hasattr(chunk, "text")
                                ]
                            )

            # Chat Completion APIの場合
            if hasattr(response, "choices"):
                return response.choices[0].message.content

            logger.error(f"不明なレスポンス形式: {type(response)}")
            return ""

        except Exception as e:
            logger.error(f"コンテンツ抽出エラー: {e}", exc_info=True)
            return ""

    def delete_conversation(self):
        """会話を削除（プライバシー対応）"""
        if self.conversation_id:
            try:
                self.client.beta.conversations.delete(
                    conversation_id=self.conversation_id
                )
                logger.info(f"会話を削除しました: {self.conversation_id}")
                self.conversation_id = None
            except Exception as e:
                logger.error(f"会話削除エラー: {e}")

    def __del__(self):
        """デストラクタ - 会話を自動削除"""
        if os.environ.get("DELETE_CONVERSATION_AFTER", "true").lower() == "true":
            self.delete_conversation()


# ヘルパー関数
def generate_briefing(
    data: Dict[str, Any], agent_id: str = None, api_key: str = None
) -> Dict[str, Any]:
    """
    ブリーフィングを生成（ヘルパー関数）

    Args:
        data: 統合データ
        agent_id: Mistral Agent ID
        api_key: Mistral API Key

    Returns:
        生成されたブリーフィング
    """
    agent = MorningBriefingAgent(agent_id=agent_id, api_key=api_key)
    return agent.generate_briefing(data)


# テスト用
if __name__ == "__main__":
    # サンプルデータでテスト
    result = generate_briefing(prompts.SAMPLE_DATA)

    print("=== テキストブリーフィング ===")
    print(result["text"])
    print("\n=== 音声スクリプト ===")
    print(result["voice_script"])
