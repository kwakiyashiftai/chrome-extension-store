"""
Morning Briefing Agent
毎朝の業務情報を収集・要約し、音声とテキストで配信するAIエージェント
"""

__version__ = "1.0.0"
__author__ = "Claude Code"

import logging
import sys
from pathlib import Path

# パッケージルートディレクトリ
PACKAGE_ROOT = Path(__file__).parent.parent
CONFIG_DIR = PACKAGE_ROOT / "config"
LOGS_DIR = PACKAGE_ROOT / "logs"

# ログディレクトリの作成
LOGS_DIR.mkdir(exist_ok=True)


def setup_logging(level: str = "INFO", log_file: str = None):
    """
    ロギングを設定

    Args:
        level: ログレベル (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: ログファイルパス（指定しない場合はコンソールのみ）
    """
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # ロガーの設定
    logger = logging.getLogger("briefing")
    logger.setLevel(getattr(logging, level.upper()))

    # ハンドラーをクリア
    logger.handlers.clear()

    # コンソールハンドラー
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, level.upper()))
    console_handler.setFormatter(logging.Formatter(log_format))
    logger.addHandler(console_handler)

    # ファイルハンドラー
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(getattr(logging, level.upper()))
        file_handler.setFormatter(logging.Formatter(log_format))
        logger.addHandler(file_handler)

    return logger


# デフォルトロガー
logger = setup_logging()
