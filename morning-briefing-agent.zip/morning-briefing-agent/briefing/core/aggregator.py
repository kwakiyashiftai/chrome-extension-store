"""
データ統合モジュール
複数のアダプターからのデータを統合し、LLM用の形式に整形
"""

import logging
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger("briefing.core.aggregator")


class DataAggregator:
    """データ統合クラス"""

    def __init__(self):
        pass

    def aggregate(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        複数ソースのデータを統合

        Args:
            raw_data: {
                "slack": {...},
                "google_calendar": {...},
                "google_docs": {...},
                ...
            }

        Returns:
            統合データ
        """
        logger.info("データ統合開始")

        # 緊急項目を抽出
        urgent_items = self._extract_urgent_items(raw_data)

        # 昨日のハイライトを抽出
        yesterday_highlights = self._extract_yesterday_highlights(raw_data)

        # 今日のスケジュールを抽出
        today_schedule = self._extract_today_schedule(raw_data)

        # 今日のタスクを抽出
        today_tasks = self._extract_today_tasks(raw_data)

        # 統合データを構築
        aggregated = {
            "date": datetime.now().strftime("%Y年%m月%d日"),
            "urgent_items": urgent_items,
            "yesterday_highlights": yesterday_highlights,
            "today_schedule": today_schedule,
            "today_tasks": today_tasks,
            "data_sources": self._get_source_status(raw_data),
        }

        logger.info(
            f"データ統合完了: "
            f"緊急{len(urgent_items)}件、"
            f"ハイライト{len(yesterday_highlights)}件、"
            f"スケジュール{len(today_schedule)}件、"
            f"タスク{len(today_tasks)}件"
        )

        return aggregated

    def _extract_urgent_items(self, raw_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """緊急項目を抽出"""
        urgent = []

        # Slackの未対応メンション
        if "slack" in raw_data and raw_data["slack"].get("status") == "success":
            slack_data = raw_data["slack"].get("data", {})
            pending_mentions = slack_data.get("pending_mentions", [])

            for mention in pending_mentions:
                # 優先度スコア50以上のみ
                if mention.get("priority_score", 0) >= 50:
                    urgent.append(
                        {
                            "source": "slack",
                            "type": "pending_mention",
                            "priority_score": mention.get("priority_score"),
                            "summary": f"{mention['author_name']}より：{mention['content'][:50]}...",
                            "detail": mention,
                        }
                    )

        # Todoistの期限超過タスク
        if "todoist" in raw_data and raw_data["todoist"].get("status") == "success":
            todoist_data = raw_data["todoist"].get("data", {})
            overdue_tasks = todoist_data.get("tasks", {}).get("overdue", [])

            for task in overdue_tasks:
                urgent.append(
                    {
                        "source": "todoist",
                        "type": "overdue_task",
                        "priority_score": task.get("priority_score", 0),
                        "summary": f"{task['title']}（{task['days_overdue']}日超過）",
                        "detail": task,
                    }
                )

        # 優先度でソート
        urgent.sort(key=lambda x: x.get("priority_score", 0), reverse=True)

        return urgent[:5]  # 最大5件

    def _extract_yesterday_highlights(
        self, raw_data: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """昨日のハイライトを抽出"""
        highlights = []

        # Slackの重要なディスカッション
        if "slack" in raw_data and raw_data["slack"].get("status") == "success":
            slack_data = raw_data["slack"].get("data", {})
            channel_history = slack_data.get("channel_history", [])

            for channel in channel_history:
                messages = channel.get("messages", [])
                # リアクションが多いメッセージ
                for msg in messages:
                    if msg.get("reaction_count", 0) >= 3:
                        highlights.append(
                            {
                                "source": "slack",
                                "type": "discussion",
                                "summary": f"[{channel['channel_name']}] {msg['content'][:50]}...",
                            }
                        )

        # Google Docsの決定事項
        if "google_docs" in raw_data and raw_data["google_docs"].get("status") == "success":
            docs_data = raw_data["google_docs"].get("data", {})
            meeting_notes = docs_data.get("meeting_notes", [])

            for note in meeting_notes:
                decisions = note.get("extracted", {}).get("decisions", [])
                for decision in decisions:
                    highlights.append(
                        {
                            "source": "google_docs",
                            "type": "decision",
                            "summary": decision,
                        }
                    )

        return highlights[:5]  # 最大5件

    def _extract_today_schedule(
        self, raw_data: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """今日のスケジュールを抽出"""
        schedule = []

        if (
            "google_calendar" in raw_data
            and raw_data["google_calendar"].get("status") == "success"
        ):
            calendar_data = raw_data["google_calendar"].get("data", {})
            events = calendar_data.get("events", [])

            for event in events:
                schedule.append(
                    {
                        "time": f"{event['start_time']}-{event['end_time']}",
                        "title": event["title"],
                        "location": event.get("location", {}).get("name", "未設定"),
                        "location_url": event.get("location", {}).get("url"),
                        "is_external": event.get("is_external_meeting", False),
                        "has_video": event.get("has_video_call", False),
                    }
                )

        return schedule

    def _extract_today_tasks(self, raw_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """今日のタスクを抽出"""
        tasks = []

        # Todoistの今日期限タスク
        if "todoist" in raw_data and raw_data["todoist"].get("status") == "success":
            todoist_data = raw_data["todoist"].get("data", {})
            today_tasks = todoist_data.get("tasks", {}).get("today", [])

            for task in today_tasks:
                tasks.append(
                    {
                        "source": "todoist",
                        "title": task["title"],
                        "due_time": task.get("due_time"),
                        "priority": task.get("priority", "normal"),
                        "url": task.get("url"),
                    }
                )

        # Google Docsの自分宛アクションアイテム
        if "google_docs" in raw_data and raw_data["google_docs"].get("status") == "success":
            docs_data = raw_data["google_docs"].get("data", {})
            meeting_notes = docs_data.get("meeting_notes", [])

            for note in meeting_notes:
                action_items = note.get("extracted", {}).get("action_items", [])
                for item in action_items:
                    if item.get("is_my_task"):
                        tasks.append(
                            {
                                "source": "google_docs",
                                "title": item["task"],
                                "due_date": item.get("due_date"),
                                "from_meeting": note["title"],
                            }
                        )

        return tasks[:10]  # 最大10件

    def _get_source_status(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """データソースのステータスを取得"""
        status = {}

        for source, data in raw_data.items():
            status[source] = {
                "status": data.get("status", "unknown"),
                "fetched_at": data.get("fetched_at"),
            }

            if data.get("error"):
                status[source]["error"] = data["error"]

        return status


# ヘルパー関数
def aggregate_data(raw_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    データを統合（ヘルパー関数）

    Args:
        raw_data: 各アダプターからの生データ

    Returns:
        統合データ
    """
    aggregator = DataAggregator()
    return aggregator.aggregate(raw_data)


# テスト用
if __name__ == "__main__":
    # サンプルデータ
    sample_raw_data = {
        "slack": {
            "status": "success",
            "fetched_at": "2025-01-12T09:00:00+09:00",
            "data": {
                "pending_mentions": [
                    {
                        "author_name": "鈴木",
                        "content": "ロゴの確認をお願いします",
                        "priority_score": 50,
                        "hours_since_posted": 18,
                    }
                ],
                "channel_history": [
                    {
                        "channel_name": "general",
                        "messages": [
                            {"content": "プロジェクト進捗", "reaction_count": 5}
                        ],
                    }
                ],
            },
        },
        "google_calendar": {
            "status": "success",
            "fetched_at": "2025-01-12T09:00:00+09:00",
            "data": {
                "events": [
                    {
                        "title": "内部MTG",
                        "start_time": "10:00",
                        "end_time": "11:00",
                        "location": {"name": "会議室A"},
                    }
                ]
            },
        },
    }

    result = aggregate_data(sample_raw_data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
