"""
設定管理モジュール
YAMLファイルと環境変数から設定を読み込む
"""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from dotenv import load_dotenv

# .envファイルを読み込み
load_dotenv()


@dataclass
class AgentConfig:
    """Mistral Agent設定"""
    id: str = ""
    model: str = "mistral-medium-2505"


@dataclass
class LLMConfig:
    """LLM設定"""
    provider: str = "mistral-api"
    base_url: str = "http://localhost:11434"
    model: str = "mistral"
    temperature: float = 0.3
    max_tokens: int = 2000
    top_p: float = 0.9
    timeout_seconds: int = 60
    retry_count: int = 3


@dataclass
class ScheduleConfig:
    """スケジュール設定"""
    time: str = "09:00"
    timezone: str = "Asia/Tokyo"
    exclude_weekends: bool = True
    exclude_holidays: bool = False


@dataclass
class SlackDataSourceConfig:
    """Slack データソース設定"""
    enabled: bool = True
    channels: list = field(default_factory=list)
    delivery_channel: str = ""
    history_hours: int = 24
    exclude_bots: bool = True


@dataclass
class GoogleCalendarDataSourceConfig:
    """Google Calendar データソース設定"""
    enabled: bool = True
    calendar_id: str = "primary"


@dataclass
class GoogleDocsDataSourceConfig:
    """Google Docs データソース設定"""
    enabled: bool = True
    folder_id: str = ""
    max_documents: int = 10


@dataclass
class TodoistDataSourceConfig:
    """Todoist データソース設定"""
    enabled: bool = False


@dataclass
class DataSourcesConfig:
    """データソース設定"""
    slack: SlackDataSourceConfig = field(default_factory=SlackDataSourceConfig)
    google_calendar: GoogleCalendarDataSourceConfig = field(default_factory=GoogleCalendarDataSourceConfig)
    google_docs: GoogleDocsDataSourceConfig = field(default_factory=GoogleDocsDataSourceConfig)
    todoist: TodoistDataSourceConfig = field(default_factory=TodoistDataSourceConfig)


@dataclass
class PriorityConfig:
    """優先度判定設定"""
    dm_mention: int = 30
    channel_mention: int = 20
    unread_hours_multiplier: float = 1.5
    overdue_task: int = 25
    today_task: int = 15
    urgent_keywords: list = field(default_factory=lambda: ["緊急", "urgent", "ASAP", "至急"])
    urgent_keyword_score: int = 20


@dataclass
class OutputConfig:
    """出力設定"""
    include_voice: bool = True
    language: str = "ja"
    delete_conversation: bool = True
    max_urgent_items: int = 5
    max_highlights: int = 5
    max_tasks: int = 10


@dataclass
class LoggingConfig:
    """ログ設定"""
    level: str = "INFO"
    file: str = "logs/briefing.log"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


@dataclass
class Credentials:
    """認証情報"""
    slack_bot_token: str = ""
    slack_signing_secret: str = ""
    google_client_id: str = ""
    google_client_secret: str = ""
    google_refresh_token: Optional[str] = None
    todoist_api_token: str = ""
    mistral_api_key: str = ""


class Config:
    """
    アプリケーション設定管理クラス
    YAMLファイルと環境変数から設定を読み込む
    """

    def __init__(self, config_dir: Path = None):
        """
        Args:
            config_dir: 設定ファイルのディレクトリ（デフォルト: プロジェクトルート/config）
        """
        if config_dir is None:
            package_root = Path(__file__).parent.parent.parent
            config_dir = package_root / "config"

        self.config_dir = Path(config_dir)

        # 設定ファイルのパス
        self.settings_file = self.config_dir / "settings.yaml"
        self.credentials_file = self.config_dir / "credentials.yaml"

        # 設定を読み込み
        self._load_settings()
        self._load_credentials()

    def _load_settings(self):
        """settings.yamlから設定を読み込む"""
        if not self.settings_file.exists():
            raise FileNotFoundError(
                f"設定ファイルが見つかりません: {self.settings_file}\n"
                f"config/settings.yaml.example をコピーして config/settings.yaml を作成してください。"
            )

        with open(self.settings_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        # 各設定セクションをデータクラスに変換
        self.agent = AgentConfig(**data.get("agent", {}))
        self.llm = LLMConfig(**data.get("llm", {}))
        self.schedule = ScheduleConfig(**data.get("schedule", {}))
        self.priority = PriorityConfig(**data.get("priority", {}))
        self.output = OutputConfig(**data.get("output", {}))
        self.logging = LoggingConfig(**data.get("logging", {}))

        # データソース設定
        ds_data = data.get("data_sources", {})
        self.data_sources = DataSourcesConfig(
            slack=SlackDataSourceConfig(**ds_data.get("slack", {})),
            google_calendar=GoogleCalendarDataSourceConfig(**ds_data.get("google_calendar", {})),
            google_docs=GoogleDocsDataSourceConfig(**ds_data.get("google_docs", {})),
            todoist=TodoistDataSourceConfig(**ds_data.get("todoist", {}))
        )

    def _load_credentials(self):
        """credentials.yamlと環境変数から認証情報を読み込む"""
        creds_data = {}

        # credentials.yamlから読み込み（存在する場合）
        if self.credentials_file.exists():
            with open(self.credentials_file, "r", encoding="utf-8") as f:
                creds_data = yaml.safe_load(f) or {}

        # 環境変数から読み込み（優先）
        self.credentials = Credentials(
            slack_bot_token=os.getenv("SLACK_BOT_TOKEN", creds_data.get("slack", {}).get("bot_token", "")),
            slack_signing_secret=os.getenv("SLACK_SIGNING_SECRET", creds_data.get("slack", {}).get("signing_secret", "")),
            google_client_id=os.getenv("GOOGLE_CLIENT_ID", creds_data.get("google", {}).get("client_id", "")),
            google_client_secret=os.getenv("GOOGLE_CLIENT_SECRET", creds_data.get("google", {}).get("client_secret", "")),
            google_refresh_token=creds_data.get("google", {}).get("refresh_token"),
            todoist_api_token=os.getenv("TODOIST_API_TOKEN", creds_data.get("todoist", {}).get("api_token", "")),
            mistral_api_key=os.getenv("MISTRAL_API_KEY", creds_data.get("mistral", {}).get("api_key", ""))
        )

        # Agent IDは環境変数から優先的に取得
        if os.getenv("BRIEFING_AGENT_ID"):
            self.agent.id = os.getenv("BRIEFING_AGENT_ID")

    def validate(self) -> list[str]:
        """
        設定の妥当性をチェック

        Returns:
            エラーメッセージのリスト（空の場合は問題なし）
        """
        errors = []

        # 必須設定のチェック
        if self.data_sources.slack.enabled and not self.credentials.slack_bot_token:
            errors.append("Slack Bot Tokenが設定されていません")

        if self.data_sources.google_calendar.enabled and not self.credentials.google_client_id:
            errors.append("Google Client IDが設定されていません")

        if self.llm.provider == "mistral-api" and not self.credentials.mistral_api_key:
            errors.append("Mistral API Keyが設定されていません")

        if not self.data_sources.slack.delivery_channel:
            errors.append("Slack配信先チャンネルが設定されていません")

        return errors

    def get_log_file_path(self) -> Path:
        """ログファイルの絶対パスを取得"""
        log_file = Path(self.logging.file)
        if not log_file.is_absolute():
            log_file = self.config_dir.parent / log_file
        return log_file

    def __repr__(self) -> str:
        """設定の文字列表現（認証情報は隠す）"""
        return (
            f"Config(\n"
            f"  agent={self.agent},\n"
            f"  llm={self.llm},\n"
            f"  schedule={self.schedule},\n"
            f"  data_sources=<{sum([s.enabled for s in [self.data_sources.slack, self.data_sources.google_calendar, self.data_sources.google_docs, self.data_sources.todoist]])} enabled>,\n"
            f"  credentials=<masked>\n"
            f")"
        )


# シングルトンインスタンス
_config_instance: Optional[Config] = None


def get_config(config_dir: Path = None) -> Config:
    """
    設定インスタンスを取得（シングルトン）

    Args:
        config_dir: 設定ファイルのディレクトリ

    Returns:
        Config: 設定インスタンス
    """
    global _config_instance

    if _config_instance is None:
        _config_instance = Config(config_dir)

    return _config_instance


def reload_config(config_dir: Path = None) -> Config:
    """
    設定を再読み込み

    Args:
        config_dir: 設定ファイルのディレクトリ

    Returns:
        Config: 新しい設定インスタンス
    """
    global _config_instance
    _config_instance = Config(config_dir)
    return _config_instance
