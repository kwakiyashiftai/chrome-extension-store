"""
優先度判定モジュール
メッセージ、タスク、イベントの優先度スコアを計算
"""

import logging
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger("briefing.core.priority")


class PriorityCalculator:
    """優先度スコア計算クラス"""

    def __init__(self, config: Dict[str, Any] = None):
        """
        Args:
            config: 優先度設定
        """
        self.config = config or {}

        # デフォルト設定
        self.dm_mention = self.config.get("dm_mention", 30)
        self.channel_mention = self.config.get("channel_mention", 20)
        self.unread_hours_multiplier = self.config.get("unread_hours_multiplier", 1.5)
        self.overdue_task = self.config.get("overdue_task", 25)
        self.today_task = self.config.get("today_task", 15)
        self.urgent_keywords = self.config.get(
            "urgent_keywords", ["緊急", "urgent", "ASAP", "至急"]
        )
        self.urgent_keyword_score = self.config.get("urgent_keyword_score", 20)

    def calculate_slack_mention_priority(
        self, mention: Dict[str, Any]
    ) -> int:
        """
        Slackメンションの優先度を計算

        Args:
            mention: メンション情報

        Returns:
            優先度スコア (0-100)
        """
        score = 0

        # DMかチャンネルか
        is_dm = mention.get("channel_name", "").lower() == "dm"
        score += self.dm_mention if is_dm else self.channel_mention

        # 経過時間
        hours_since = mention.get("hours_since_posted", 0)
        if hours_since > 24:
            score += int((hours_since / 24) * self.unread_hours_multiplier * 10)

        # 緊急キーワード
        content = mention.get("content", "").lower()
        for keyword in self.urgent_keywords:
            if keyword.lower() in content:
                score += self.urgent_keyword_score
                break

        return min(score, 100)

    def calculate_task_priority(self, task: Dict[str, Any], current_date: datetime) -> int:
        """
        タスクの優先度を計算

        Args:
            task: タスク情報
            current_date: 現在日時

        Returns:
            優先度スコア (0-100)
        """
        score = 0

        # 期限超過チェック
        if task.get("days_overdue", 0) > 0:
            score += self.overdue_task
            score += task["days_overdue"] * 5  # 1日ごとに+5点

        # 今日期限チェック
        elif task.get("due_date") == current_date.strftime("%Y-%m-%d"):
            score += self.today_task

        # 優先度レベル
        priority_level = task.get("priority", "").lower()
        if priority_level == "urgent":
            score += 20
        elif priority_level == "high":
            score += 10

        # 緊急キーワード
        title = task.get("title", "").lower()
        for keyword in self.urgent_keywords:
            if keyword.lower() in title:
                score += self.urgent_keyword_score
                break

        return min(score, 100)

    def calculate_meeting_priority(self, event: Dict[str, Any]) -> int:
        """
        会議の優先度を計算

        Args:
            event: イベント情報

        Returns:
            優先度スコア (0-100)
        """
        score = 0

        # 外部ミーティング
        if event.get("is_external_meeting"):
            score += 15

        # 自分が主催者
        if event.get("is_organizer"):
            score += 10

        # 参加者数（大規模会議）
        attendees_count = event.get("attendees_count", 0)
        if attendees_count > 10:
            score += 10
        elif attendees_count > 5:
            score += 5

        # 継続時間（長時間会議）
        duration = event.get("duration_minutes", 0)
        if duration > 120:  # 2時間以上
            score += 10
        elif duration > 60:  # 1時間以上
            score += 5

        # タイトルに緊急キーワード
        title = event.get("title", "").lower()
        for keyword in self.urgent_keywords:
            if keyword.lower() in title:
                score += self.urgent_keyword_score
                break

        return min(score, 100)

    def classify_items(
        self, items: List[Dict[str, Any]], threshold: int = 50
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        項目を優先度で分類

        Args:
            items: 項目リスト（各項目にpriority_scoreが含まれる）
            threshold: 緊急判定の閾値

        Returns:
            分類された項目 {"urgent": [...], "normal": [...]}
        """
        urgent = []
        normal = []

        for item in items:
            score = item.get("priority_score", 0)
            if score >= threshold:
                urgent.append(item)
            else:
                normal.append(item)

        # 優先度でソート（降順）
        urgent.sort(key=lambda x: x.get("priority_score", 0), reverse=True)
        normal.sort(key=lambda x: x.get("priority_score", 0), reverse=True)

        return {"urgent": urgent, "normal": normal}


def calculate_all_priorities(
    aggregated_data: Dict[str, Any], config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    すべてのデータの優先度を計算（ヘルパー関数）

    Args:
        aggregated_data: 統合データ
        config: 優先度設定

    Returns:
        優先度スコア付きデータ
    """
    calculator = PriorityCalculator(config)
    current_date = datetime.now()

    # Slackメンションの優先度計算
    if "slack" in aggregated_data:
        for mention in aggregated_data["slack"].get("pending_mentions", []):
            mention["priority_score"] = calculator.calculate_slack_mention_priority(
                mention
            )

    # タスクの優先度計算
    if "todoist" in aggregated_data:
        for task in aggregated_data["todoist"].get("tasks", {}).get("overdue", []):
            task["priority_score"] = calculator.calculate_task_priority(
                task, current_date
            )

        for task in aggregated_data["todoist"].get("tasks", {}).get("today", []):
            task["priority_score"] = calculator.calculate_task_priority(
                task, current_date
            )

    # 会議の優先度計算
    if "google_calendar" in aggregated_data:
        for event in aggregated_data["google_calendar"].get("events", []):
            event["priority_score"] = calculator.calculate_meeting_priority(event)

    logger.info("優先度計算完了")

    return aggregated_data


# テスト用
if __name__ == "__main__":
    calculator = PriorityCalculator()

    # テスト: Slackメンション
    mention = {
        "channel_name": "dm",
        "hours_since_posted": 30,
        "content": "緊急でお願いします",
    }
    score = calculator.calculate_slack_mention_priority(mention)
    print(f"メンション優先度: {score}")

    # テスト: タスク
    task = {
        "days_overdue": 2,
        "priority": "urgent",
        "title": "ASAP対応が必要",
    }
    score = calculator.calculate_task_priority(task, datetime.now())
    print(f"タスク優先度: {score}")
