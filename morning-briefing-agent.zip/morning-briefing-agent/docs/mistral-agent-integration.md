# Mistral Agent SDK 統合ガイド

本ドキュメントでは、モーニング・ブリーフィング・エージェントをMistral Agent APIを使って実装する方法を説明します。

---

## 目次

1. [Mistral Agent API 概要](#1-mistral-agent-api-概要)
2. [環境セットアップ](#2-環境セットアップ)
3. [エージェント設計](#3-エージェント設計)
4. [実装サンプル](#4-実装サンプル)
5. [ツール統合](#5-ツール統合)
6. [会話管理](#6-会話管理)
7. [本番運用設定](#7-本番運用設定)

---

## 1. Mistral Agent API 概要

### 1.1 主要コンセプト

| コンセプト | 説明 |
|-----------|------|
| **Agent** | 事前定義された指示・ツール・パラメータを持つモデルの拡張 |
| **Conversation** | エージェントとの対話履歴を永続化する仕組み |
| **Entry** | 会話内の各アクション（メッセージ、ツール実行など） |
| **Connectors** | 組み込みツール（Web検索、コード実行、画像生成など） |

### 1.2 利用可能な組み込みツール

| ツール | タイプ | 用途 |
|--------|-------|------|
| Web Search | `web_search` | ウェブ検索 |
| Code Interpreter | `code_interpreter` | Pythonコード実行 |
| Image Generation | `image_generation` | 画像生成 |
| Document Library | `document_library` | RAG/ドキュメント検索 |
| Function Calling | `function` | カスタム関数呼び出し |

### 1.3 APIエンドポイント

```
Base URL: https://api.mistral.ai/v1

# Agent管理
POST   /agents              - エージェント作成
GET    /agents/{agent_id}   - エージェント取得
PATCH  /agents/{agent_id}   - エージェント更新
DELETE /agents/{agent_id}   - エージェント削除

# 会話管理
POST   /conversations                    - 会話開始
POST   /conversations/{id}               - 会話継続
GET    /conversations/{id}               - 会話取得
GET    /conversations/{id}/entries       - エントリー一覧
DELETE /conversations/{id}               - 会話削除
```

---

## 2. 環境セットアップ

### 2.1 必要なパッケージ

```bash
# Mistral SDK
pip install mistralai

# その他依存関係
pip install python-dotenv httpx
```

### 2.2 環境変数設定

```bash
# .env ファイル
MISTRAL_API_KEY=your_api_key_here

# Slack連携用
SLACK_BOT_TOKEN=xoxb-xxxx
SLACK_SIGNING_SECRET=xxxx

# Google連携用
GOOGLE_CLIENT_ID=xxxx
GOOGLE_CLIENT_SECRET=xxxx
```

### 2.3 基本的なクライアント初期化

```python
import os
from mistralai import Mistral
from dotenv import load_dotenv

load_dotenv()

client = Mistral(api_key=os.environ.get("MISTRAL_API_KEY"))
```

---

## 3. エージェント設計

### 3.1 モーニングブリーフィング用エージェント構成

```
┌─────────────────────────────────────────────────────────────────┐
│                    Briefing Agent System                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────┐     ┌──────────────────┐                  │
│  │  Data Collector  │────▶│  Summarizer      │                  │
│  │  Agent           │     │  Agent           │                  │
│  │                  │     │                  │                  │
│  │  - Slack取得     │     │  - 要約生成      │                  │
│  │  - Calendar取得  │     │  - 優先度判定    │                  │
│  │  - Docs取得      │     │  - 音声スクリプト│                  │
│  └──────────────────┘     └──────────────────┘                  │
│           │                        │                            │
│           ▼                        ▼                            │
│  ┌──────────────────────────────────────────┐                   │
│  │            Orchestrator Agent            │                   │
│  │                                          │                   │
│  │  - 全体フロー制御                        │                   │
│  │  - エラーハンドリング                    │                   │
│  │  - 出力フォーマット統一                  │                   │
│  └──────────────────────────────────────────┘                   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 シンプル構成（単一エージェント）

まずは単一エージェントで実装し、必要に応じてマルチエージェントに拡張します。

```python
# エージェント定義
BRIEFING_AGENT_CONFIG = {
    "model": "mistral-medium-2505",
    "name": "Morning Briefing Agent",
    "description": "毎朝の業務情報を収集・要約し、ブリーフィングを生成するエージェント",
    "instructions": """
あなたは優秀なビジネスアシスタントです。
ユーザーの業務情報を分析し、朝のブリーフィングを作成します。

## タスク
1. 提供されたデータ（Slack、カレンダー、議事録、タスク）を分析
2. 重要度に基づいて情報を分類
3. 簡潔で読みやすいブリーフィングを生成

## 出力ルール
- 簡潔で要点を押さえた日本語で書く
- 重要度の高い項目から順に記載
- 箇条書きを活用し、読みやすく整形
- 推測や補足は入れず、与えられた情報のみを要約

## 分類カテゴリ
1. 🔴 要対応: 緊急対応が必要な項目
2. 📋 昨日の振り返り: 前日の重要な出来事
3. 📅 本日のスケジュール: 今日の予定
4. ✅ 今日のToDo: 今日のタスク
""",
    "tools": [
        {"type": "web_search"},  # 最新情報取得用
        {"type": "code_interpreter"},  # データ処理用
    ],
    "completion_args": {
        "temperature": 0.3,
        "top_p": 0.9,
        "max_tokens": 2000,
    }
}
```

---

## 4. 実装サンプル

### 4.1 エージェント作成

```python
import os
from mistralai import Mistral

client = Mistral(api_key=os.environ.get("MISTRAL_API_KEY"))

def create_briefing_agent():
    """ブリーフィングエージェントを作成"""
    
    agent = client.beta.agents.create(
        model="mistral-medium-2505",
        name="Morning Briefing Agent",
        description="毎朝の業務情報を収集・要約し、ブリーフィングを生成するエージェント",
        instructions="""
あなたは優秀なビジネスアシスタントです。
ユーザーの業務情報を分析し、朝のブリーフィングを作成します。

## 出力フォーマット
以下のMarkdown形式で出力してください：

🌅 **{日付} Morning Briefing**

---

**🔴 要対応**
• [箇条書きで記載]

---

**📋 昨日の振り返り**
• [箇条書きで記載]

---

**📅 本日のスケジュール**
| 時間 | 予定 | 場所 |
|-----|------|------|

---

**✅ 今日のToDo**
• [ ] [タスク名]

---
""",
        tools=[
            {"type": "code_interpreter"},
        ],
        completion_args={
            "temperature": 0.3,
            "max_tokens": 2000,
        }
    )
    
    print(f"Agent created: {agent.id}")
    return agent

# 既存のAgent IDを使用する場合
AGENT_ID = "ag_019bae3bfe5a75a782f1db7115e5eea5"  # マスターの作成済みAgent
```

### 4.2 ブリーフィング生成（基本版）

```python
import json
from datetime import datetime

def generate_briefing(agent_id: str, data: dict) -> str:
    """
    ブリーフィングを生成する
    
    Args:
        agent_id: Mistral Agent ID
        data: 収集済みの業務データ（正規化済み）
    
    Returns:
        生成されたブリーフィングテキスト
    """
    
    # 入力プロンプトを構築
    today = datetime.now().strftime("%Y年%m月%d日（%a）")
    
    prompt = f"""
以下の業務データを基に、{today}の朝のブリーフィングを作成してください。

## 入力データ
```json
{json.dumps(data, ensure_ascii=False, indent=2)}
```

上記のデータを分析し、指定されたフォーマットでブリーフィングを生成してください。
データがないセクションは「特になし」と記載してください。
"""
    
    # 会話を開始
    response = client.beta.conversations.start(
        agent_id=agent_id,
        inputs=[{"role": "user", "content": prompt}],
    )
    
    # レスポンスからテキストを抽出
    briefing_text = extract_assistant_message(response)
    
    return briefing_text

def extract_assistant_message(response) -> str:
    """レスポンスからアシスタントのメッセージを抽出"""
    for entry in response.outputs:
        if hasattr(entry, 'content') and entry.role == 'assistant':
            return entry.content
    return ""
```

### 4.3 完全な実装例

```python
import os
import json
from datetime import datetime, timedelta
from mistralai import Mistral
from dotenv import load_dotenv

# 環境変数読み込み
load_dotenv()

class MorningBriefingAgent:
    """モーニングブリーフィングエージェント"""
    
    def __init__(self, agent_id: str = None):
        self.client = Mistral(api_key=os.environ.get("MISTRAL_API_KEY"))
        self.agent_id = agent_id or os.environ.get("BRIEFING_AGENT_ID")
        self.conversation_id = None
    
    def generate_briefing(self, data: dict) -> dict:
        """
        ブリーフィングを生成
        
        Returns:
            {
                "text": str,           # Markdown形式のブリーフィング
                "voice_script": str,   # 音声用スクリプト
                "conversation_id": str # 会話ID（継続用）
            }
        """
        today = datetime.now().strftime("%Y年%m月%d日（%a）")
        
        # Step 1: テキストブリーフィング生成
        text_prompt = self._build_text_prompt(today, data)
        text_response = self.client.beta.conversations.start(
            agent_id=self.agent_id,
            inputs=[{"role": "user", "content": text_prompt}],
        )
        
        briefing_text = self._extract_content(text_response)
        self.conversation_id = text_response.conversation_id
        
        # Step 2: 音声スクリプト生成（同じ会話を継続）
        voice_prompt = """
上記のブリーフィングを、音声読み上げ用のスクリプトに変換してください。

ルール:
- 自然で聞き取りやすい日本語
- 数字は「じゅう」「にじゅう」と読み仮名で
- URLは「ズームのリンク」のように省略
- 3分程度の長さに
"""
        
        voice_response = self.client.beta.conversations.append(
            conversation_id=self.conversation_id,
            inputs=[{"role": "user", "content": voice_prompt}],
        )
        
        voice_script = self._extract_content(voice_response)
        
        return {
            "text": briefing_text,
            "voice_script": voice_script,
            "conversation_id": self.conversation_id,
        }
    
    def _build_text_prompt(self, date: str, data: dict) -> str:
        """テキスト生成用プロンプトを構築"""
        return f"""
以下の業務データを基に、{date}の朝のブリーフィングを作成してください。

## 入力データ
```json
{json.dumps(data, ensure_ascii=False, indent=2)}
```

## 出力フォーマット

🌅 **{date} Morning Briefing**

---

**🔴 要対応**
• [priority_scoreが50以上の項目を記載]

---

**📋 昨日の振り返り**
• [yesterday_highlightsの内容]

---

**📅 本日のスケジュール**
| 時間 | 予定 | 場所 |
|-----|------|------|
| [時間] | [タイトル] | [場所/URL] |

---

**✅ 今日のToDo**
• [ ] [タスク名]（[締切]）

---

データがないセクションは「特になし」と記載してください。
"""
    
    def _extract_content(self, response) -> str:
        """レスポンスからコンテンツを抽出"""
        for entry in response.outputs:
            if hasattr(entry, 'content'):
                if isinstance(entry.content, str):
                    return entry.content
                elif isinstance(entry.content, list):
                    # TextChunkの場合
                    return "".join([
                        chunk.text for chunk in entry.content 
                        if hasattr(chunk, 'text')
                    ])
        return ""


# 使用例
if __name__ == "__main__":
    # サンプルデータ
    sample_data = {
        "date": "2025年1月12日（日）",
        "urgent_items": [
            {
                "source": "slack",
                "summary": "ロゴ修正案の確認依頼",
                "author": "鈴木",
                "channel": "project-a",
                "hours_since": 18,
                "priority_score": 50
            }
        ],
        "yesterday_highlights": [
            {"source": "slack", "summary": "プロジェクトBの進捗について合意形成"},
            {"source": "google_docs", "summary": "次期フェーズの予算を20%増額で決定"}
        ],
        "today_schedule": [
            {"time": "10:00-11:00", "title": "内部MTG", "location": "会議室A"},
            {"time": "15:00-16:00", "title": "クライアント商談", "location": "https://zoom.us/j/123456"}
        ],
        "today_tasks": [
            {"title": "報告書の提出", "due_time": "18:00", "priority": "urgent"},
            {"title": "デザインレビュー", "due_time": None, "priority": "high"}
        ]
    }
    
    # エージェント実行
    agent = MorningBriefingAgent(agent_id="ag_019bae3bfe5a75a782f1db7115e5eea5")
    result = agent.generate_briefing(sample_data)
    
    print("=== テキストブリーフィング ===")
    print(result["text"])
    print("\n=== 音声スクリプト ===")
    print(result["voice_script"])
```

---

## 5. ツール統合

### 5.1 カスタム関数（Function Calling）の定義

外部API（Slack、Google等）を呼び出すカスタムツールを定義できます。

```python
# カスタムツール定義
CUSTOM_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "fetch_slack_messages",
            "description": "指定したSlackチャンネルのメッセージを取得する",
            "parameters": {
                "type": "object",
                "properties": {
                    "channel_id": {
                        "type": "string",
                        "description": "SlackチャンネルID"
                    },
                    "since_hours": {
                        "type": "integer",
                        "description": "何時間前からのメッセージを取得するか",
                        "default": 24
                    }
                },
                "required": ["channel_id"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "fetch_calendar_events",
            "description": "Googleカレンダーから今日の予定を取得する",
            "parameters": {
                "type": "object",
                "properties": {
                    "date": {
                        "type": "string",
                        "description": "取得する日付（YYYY-MM-DD形式）"
                    }
                },
                "required": ["date"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "send_to_slack",
            "description": "Slackにメッセージを送信する",
            "parameters": {
                "type": "object",
                "properties": {
                    "channel": {
                        "type": "string",
                        "description": "送信先チャンネルまたはDM"
                    },
                    "message": {
                        "type": "string",
                        "description": "送信するメッセージ"
                    }
                },
                "required": ["channel", "message"]
            }
        }
    }
]

# ツール付きエージェント作成
agent_with_tools = client.beta.agents.create(
    model="mistral-medium-2505",
    name="Briefing Agent with Tools",
    instructions="...",
    tools=CUSTOM_TOOLS + [{"type": "web_search"}],
)
```

### 5.2 ツール実行のハンドリング

```python
def handle_tool_calls(response, tool_handlers: dict):
    """
    ツール呼び出しを処理する
    
    Args:
        response: Mistral APIレスポンス
        tool_handlers: {関数名: 実行関数} の辞書
    """
    results = []
    
    for entry in response.outputs:
        if entry.type == "function_call":
            func_name = entry.name
            func_args = json.loads(entry.arguments)
            
            if func_name in tool_handlers:
                result = tool_handlers[func_name](**func_args)
                results.append({
                    "call_id": entry.id,
                    "result": json.dumps(result, ensure_ascii=False)
                })
    
    return results

# ツールハンドラー定義
TOOL_HANDLERS = {
    "fetch_slack_messages": fetch_slack_messages,
    "fetch_calendar_events": fetch_calendar_events,
    "send_to_slack": send_to_slack,
}
```

---

## 6. 会話管理

### 6.1 会話の継続

```python
def continue_conversation(conversation_id: str, message: str):
    """既存の会話を継続"""
    
    response = client.beta.conversations.append(
        conversation_id=conversation_id,
        inputs=[{"role": "user", "content": message}],
    )
    
    return response

# 例: フォローアップ質問
response = continue_conversation(
    conversation_id="conv_xxxxx",
    message="このブリーフィングを英語に翻訳してください"
)
```

### 6.2 会話履歴の取得

```python
def get_conversation_history(conversation_id: str):
    """会話の全エントリーを取得"""
    
    entries = client.beta.conversations.get_entries(
        conversation_id=conversation_id
    )
    
    return entries
```

### 6.3 会話の削除（プライバシー対応）

```python
def delete_conversation(conversation_id: str):
    """会話を削除（データ保持ポリシー対応）"""
    
    client.beta.conversations.delete(
        conversation_id=conversation_id
    )
```

---

## 7. 本番運用設定

### 7.1 スケジュール実行スクリプト

```python
#!/usr/bin/env python3
"""
Morning Briefing Agent - 定期実行スクリプト
cron: 50 8 * * 1-5 python run_briefing.py
"""

import os
import sys
import logging
from datetime import datetime
from dotenv import load_dotenv

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/briefing.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()

def main():
    try:
        logger.info("=== ブリーフィング生成開始 ===")
        
        # 1. データ収集
        logger.info("データ収集中...")
        from data_collectors import collect_all_data
        data = collect_all_data()
        
        # 2. ブリーフィング生成
        logger.info("ブリーフィング生成中...")
        from briefing_agent import MorningBriefingAgent
        agent = MorningBriefingAgent()
        result = agent.generate_briefing(data)
        
        # 3. Slack配信
        logger.info("Slack配信中...")
        from slack_sender import send_briefing
        send_briefing(
            text=result["text"],
            voice_script=result["voice_script"]
        )
        
        # 4. 会話削除（プライバシー対応）
        if os.environ.get("DELETE_CONVERSATION_AFTER", "true") == "true":
            from mistralai import Mistral
            client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
            client.beta.conversations.delete(result["conversation_id"])
            logger.info("会話履歴を削除しました")
        
        logger.info("=== ブリーフィング生成完了 ===")
        
    except Exception as e:
        logger.error(f"エラー発生: {e}", exc_info=True)
        
        # エラー通知
        from slack_sender import send_error_notification
        send_error_notification(str(e))
        
        sys.exit(1)

if __name__ == "__main__":
    main()
```

### 7.2 設定ファイル

```yaml
# config/settings.yaml

agent:
  id: "ag_019bae3bfe5a75a782f1db7115e5eea5"
  model: "mistral-medium-2505"

schedule:
  time: "09:00"
  timezone: "Asia/Tokyo"
  exclude_weekends: true
  exclude_holidays: false

data_sources:
  slack:
    enabled: true
    channels:
      - "general"
      - "project-a"
    delivery_channel: "@your-username"
  
  google_calendar:
    enabled: true
  
  google_docs:
    enabled: true
    folder_id: "your_folder_id"
  
  todoist:
    enabled: false

output:
  include_voice: true
  language: "ja"
  delete_conversation: true

logging:
  level: "INFO"
  file: "logs/briefing.log"
```

### 7.3 エラーハンドリング

```python
from functools import wraps
import time

def retry_with_backoff(max_retries=3, base_delay=1):
    """指数バックオフでリトライするデコレータ"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    delay = base_delay * (2 ** attempt)
                    logger.warning(f"リトライ {attempt + 1}/{max_retries}: {e}")
                    time.sleep(delay)
        return wrapper
    return decorator

@retry_with_backoff(max_retries=3)
def generate_briefing_with_retry(agent, data):
    """リトライ付きブリーフィング生成"""
    return agent.generate_briefing(data)
```

---

## 付録: クイックスタート

### 最小構成での実行

```python
import os
from mistralai import Mistral

# 初期化
client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

# 既存のAgent IDを使用
AGENT_ID = "ag_019bae3bfe5a75a782f1db7115e5eea5"

# シンプルなブリーフィング生成
response = client.beta.conversations.start(
    agent_id=AGENT_ID,
    inputs=[{
        "role": "user", 
        "content": """
以下のデータでブリーフィングを作成してください：

要対応: 鈴木さんからロゴ確認依頼（18時間経過）
今日の予定: 10時 内部MTG、15時 商談
タスク: 報告書提出（18時締切）
"""
    }],
)

# 結果表示
for entry in response.outputs:
    if hasattr(entry, 'content'):
        print(entry.content)
```

---

*最終更新: 2025-01-12*
