# 拡張ガイド：新しいデータソースの追加

本ドキュメントでは、モーニング・ブリーフィング・エージェントに新しい情報ソースを追加する方法と、将来的に統合を検討すべきサービス一覧を記載します。

---

## 目次

1. [拡張アーキテクチャ](#1-拡張アーキテクチャ)
2. [新規データソース追加の手順](#2-新規データソース追加の手順)
3. [将来統合候補のデータソース一覧](#3-将来統合候補のデータソース一覧)
4. [優先度判定への統合](#4-優先度判定への統合)
5. [プロンプト拡張ガイド](#5-プロンプト拡張ガイド)

---

## 1. 拡張アーキテクチャ

### 1.1 プラグイン設計思想

新しいデータソースは「Adapter」として実装し、コア処理に影響を与えずに追加・削除できる設計とします。

```
┌─────────────────────────────────────────────────────────────────┐
│                        Adapter Layer                            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │ Slack    │ │ Google   │ │ GitHub   │ │ Notion   │  ...      │
│  │ Adapter  │ │ Adapter  │ │ Adapter  │ │ Adapter  │           │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘           │
│       │            │            │            │                  │
│       └────────────┴────────────┴────────────┘                  │
│                          │                                      │
│                          ▼                                      │
│              ┌───────────────────────┐                          │
│              │   Normalizer Layer    │                          │
│              │ (共通フォーマット変換) │                          │
│              └───────────┬───────────┘                          │
│                          │                                      │
│                          ▼                                      │
│              ┌───────────────────────┐                          │
│              │    Aggregator Layer   │                          │
│              │   (統合・優先度判定)   │                          │
│              └───────────────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 Adapterインターフェース

すべてのAdapterは以下のインターフェースを実装します:

```python
from abc import ABC, abstractmethod
from typing import Optional
from datetime import datetime

class BaseAdapter(ABC):
    """データソースアダプターの基底クラス"""
    
    @property
    @abstractmethod
    def source_name(self) -> str:
        """データソース名を返す（例: 'slack', 'github'）"""
        pass
    
    @property
    @abstractmethod
    def source_display_name(self) -> str:
        """表示用名称を返す（例: 'Slack', 'GitHub'）"""
        pass
    
    @abstractmethod
    async def authenticate(self) -> bool:
        """認証を実行し、成功したらTrueを返す"""
        pass
    
    @abstractmethod
    async def fetch_data(
        self, 
        target_date: datetime,
        config: dict
    ) -> dict:
        """
        指定日のデータを取得し、正規化フォーマットで返す
        
        Returns:
            {
                "source": str,
                "fetched_at": str (ISO format),
                "status": "success" | "error" | "partial",
                "data": dict | None,
                "error": dict | None
            }
        """
        pass
    
    @abstractmethod
    def get_required_scopes(self) -> list[str]:
        """必要な認証スコープのリストを返す"""
        pass
    
    @abstractmethod
    def get_config_schema(self) -> dict:
        """設定項目のJSONスキーマを返す"""
        pass
```

### 1.3 正規化データフォーマット

各Adapterは以下のカテゴリに分類されたデータを返します:

```python
NORMALIZED_CATEGORIES = {
    "urgent_items": [
        # 緊急対応が必要な項目
        # 例: 未返信メンション、期限超過タスク、障害アラート
    ],
    "yesterday_highlights": [
        # 昨日の重要な出来事
        # 例: 決定事項、マージされたPR、完了したタスク
    ],
    "today_schedule": [
        # 今日の予定
        # 例: 会議、デッドライン、リリース予定
    ],
    "today_tasks": [
        # 今日やるべきこと
        # 例: タスク、レビュー依頼、承認待ち
    ],
    "fyi_items": [
        # 参考情報（優先度低）
        # 例: チームの活動、業界ニュース
    ]
}
```

---

## 2. 新規データソース追加の手順

### Step 1: Adapterクラスの作成

```python
# adapters/github_adapter.py

from .base import BaseAdapter
from datetime import datetime
import httpx

class GitHubAdapter(BaseAdapter):
    
    @property
    def source_name(self) -> str:
        return "github"
    
    @property
    def source_display_name(self) -> str:
        return "GitHub"
    
    async def authenticate(self) -> bool:
        # GitHub認証ロジック
        pass
    
    async def fetch_data(self, target_date: datetime, config: dict) -> dict:
        try:
            # データ取得ロジック
            prs = await self._fetch_pull_requests(config)
            issues = await self._fetch_assigned_issues(config)
            notifications = await self._fetch_notifications(config)
            
            return {
                "source": self.source_name,
                "fetched_at": datetime.now().isoformat(),
                "status": "success",
                "data": self._normalize(prs, issues, notifications),
                "error": None
            }
        except Exception as e:
            return {
                "source": self.source_name,
                "fetched_at": datetime.now().isoformat(),
                "status": "error",
                "data": None,
                "error": {"code": "FETCH_ERROR", "message": str(e)}
            }
    
    def _normalize(self, prs, issues, notifications) -> dict:
        """GitHub固有データを共通フォーマットに変換"""
        return {
            "urgent_items": self._extract_urgent(prs, issues),
            "yesterday_highlights": self._extract_highlights(prs),
            "today_tasks": self._extract_tasks(issues, prs),
            "fyi_items": self._extract_fyi(notifications)
        }
```

### Step 2: 設定スキーマの定義

```python
def get_config_schema(self) -> dict:
    return {
        "type": "object",
        "properties": {
            "repositories": {
                "type": "array",
                "items": {"type": "string"},
                "description": "監視するリポジトリ（owner/repo形式）",
                "examples": ["myorg/frontend", "myorg/backend"]
            },
            "include_drafts": {
                "type": "boolean",
                "default": False,
                "description": "ドラフトPRを含めるか"
            },
            "notification_types": {
                "type": "array",
                "items": {
                    "type": "string",
                    "enum": ["review_requested", "mention", "assign", "ci_failed"]
                },
                "default": ["review_requested", "mention"]
            }
        },
        "required": ["repositories"]
    }
```

### Step 3: Adapter登録

```python
# adapters/__init__.py

from .slack_adapter import SlackAdapter
from .google_calendar_adapter import GoogleCalendarAdapter
from .google_docs_adapter import GoogleDocsAdapter
from .todoist_adapter import TodoistAdapter
from .github_adapter import GitHubAdapter  # 追加

AVAILABLE_ADAPTERS = {
    "slack": SlackAdapter,
    "google_calendar": GoogleCalendarAdapter,
    "google_docs": GoogleDocsAdapter,
    "todoist": TodoistAdapter,
    "github": GitHubAdapter,  # 追加
}
```

### Step 4: 設定ファイルへの追加

```yaml
# config/settings.yaml

data_sources:
  slack:
    enabled: true
    # ... 既存設定
  
  github:  # 追加
    enabled: true
    repositories:
      - "myorg/frontend"
      - "myorg/backend"
    include_drafts: false
    notification_types:
      - "review_requested"
      - "mention"
      - "ci_failed"
```

### Step 5: テストの追加

```python
# tests/test_github_adapter.py

import pytest
from adapters.github_adapter import GitHubAdapter

@pytest.fixture
def adapter():
    return GitHubAdapter()

@pytest.mark.asyncio
async def test_fetch_data_success(adapter, mock_github_api):
    result = await adapter.fetch_data(
        target_date=datetime.now(),
        config={"repositories": ["test/repo"]}
    )
    assert result["status"] == "success"
    assert "urgent_items" in result["data"]
```

---

## 3. 将来統合候補のデータソース一覧

### 3.1 高優先度（ビジネスインパクト大）

| サービス | 取得できる情報 | ユースケース | 実装難易度 |
|---------|--------------|-------------|-----------|
| **Gmail** | 未読メール、重要フラグ付きメール | メール対応漏れ防止 | 中 |
| **GitHub/GitLab** | PR、Issue、レビュー依頼、CI状況 | 開発者の日次業務 | 低 |
| **Jira** | 担当チケット、ステータス変更 | プロジェクト管理 | 中 |
| **Notion** | タスク、データベース更新 | ナレッジ管理 | 低 |
| **Asana** | タスク、プロジェクト進捗 | タスク管理 | 低 |
| **Microsoft Teams** | チャット、会議予定 | MS環境ユーザー | 中 |
| **Outlook Calendar** | 予定、会議招待 | MS環境ユーザー | 中 |

### 3.2 中優先度（特定ユースケース）

| サービス | 取得できる情報 | ユースケース | 実装難易度 |
|---------|--------------|-------------|-----------|
| **Salesforce** | 商談状況、タスク | 営業担当者 | 高 |
| **HubSpot** | 顧客対応状況、タスク | マーケ・営業 | 中 |
| **Zendesk** | チケット、対応状況 | サポート担当者 | 中 |
| **Figma** | コメント、更新通知 | デザイナー | 低 |
| **Linear** | Issue、サイクル進捗 | スタートアップ開発 | 低 |
| **ClickUp** | タスク、ゴール進捗 | プロジェクト管理 | 低 |

### 3.3 低優先度（ニッチ/将来検討）

| サービス | 取得できる情報 | ユースケース | 実装難易度 |
|---------|--------------|-------------|-----------|
| **Confluence** | ページ更新、コメント | ドキュメント管理 | 中 |
| **Trello** | カード移動、期限 | カンバン管理 | 低 |
| **Discord** | メンション、チャンネル活動 | コミュニティ管理 | 低 |
| **RSS/Atom** | 業界ニュース、ブログ更新 | 情報収集 | 低 |
| **Twitter/X** | メンション、DM | SNS管理 | 中 |
| **PagerDuty** | インシデント、オンコール | SRE/運用 | 低 |
| **Datadog** | アラート、異常検知 | 監視 | 低 |

### 3.4 情報ソース選定の判断基準

新しいデータソースを追加する際は、以下の観点で評価します:

```
┌─────────────────────────────────────────────────────────────────┐
│  評価軸                    配点    閾値                         │
├─────────────────────────────────────────────────────────────────┤
│  1. 日常的な利用頻度        /30    週3回以上使用するサービス     │
│  2. 見落としリスク          /25    見落とすと業務に支障がある    │
│  3. 情報の鮮度重要性        /20    毎日確認が必要な情報          │
│  4. API提供・安定性         /15    公式API、レート制限が緩い     │
│  5. 実装・保守コスト        /10    認証が容易、ドキュメント充実  │
├─────────────────────────────────────────────────────────────────┤
│  合計 70点以上 → 高優先で実装                                    │
│  合計 50-69点  → 中優先（リソース次第）                          │
│  合計 50点未満 → 低優先（要望があれば検討）                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. 優先度判定への統合

### 4.1 データソース別の優先度スコア設定

新しいデータソースを追加する際は、優先度スコアのルールも定義します。

```yaml
# config/priority_rules.yaml

scoring_rules:
  slack:
    dm_mention: 30
    channel_mention: 20
    unread_hours_multiplier: 1.5  # 24時間超過で1.5倍
    keywords:
      - pattern: "緊急|urgent|ASAP"
        score: 20
  
  github:  # 新規追加例
    review_requested: 25
    ci_failed: 30
    issue_assigned: 15
    pr_merged: 5  # FYI扱い
    mention_in_comment: 20
    
  jira:  # 新規追加例
    high_priority_ticket: 25
    blocker_ticket: 35
    due_today: 20
    overdue: 30
    status_changed_to_review: 15
```

### 4.2 カテゴリマッピング

```python
# 各データソースのイベントをどのカテゴリに分類するか

CATEGORY_MAPPING = {
    "github": {
        "urgent_items": [
            "review_requested",
            "ci_failed", 
            "security_alert"
        ],
        "yesterday_highlights": [
            "pr_merged",
            "release_published"
        ],
        "today_tasks": [
            "issue_assigned",
            "review_requested"
        ],
        "fyi_items": [
            "star_added",
            "fork_created"
        ]
    },
    "jira": {
        "urgent_items": [
            "blocker_ticket",
            "overdue_ticket"
        ],
        "yesterday_highlights": [
            "ticket_resolved",
            "sprint_completed"
        ],
        "today_tasks": [
            "assigned_ticket",
            "due_today"
        ]
    }
}
```

---

## 5. プロンプト拡張ガイド

### 5.1 新データソース用のプロンプトセクション追加

新しいデータソースを追加したら、LLMへのプロンプトも更新します。

```python
# prompts/briefing_prompt.py

def build_prompt(aggregated_data: dict) -> str:
    sections = []
    
    # 既存セクション
    sections.append(build_slack_section(aggregated_data.get("slack")))
    sections.append(build_calendar_section(aggregated_data.get("calendar")))
    
    # 新規セクション（GitHub）
    if "github" in aggregated_data:
        sections.append(build_github_section(aggregated_data["github"]))
    
    return MAIN_TEMPLATE.format(
        data_sections="\n\n".join(sections),
        # ...
    )

def build_github_section(data: dict) -> str:
    if not data:
        return ""
    
    return f"""
## GitHub アクティビティ

### レビュー依頼
{format_review_requests(data.get("review_requests", []))}

### 自分のPRステータス
{format_my_prs(data.get("my_prs", []))}

### 担当Issue
{format_assigned_issues(data.get("assigned_issues", []))}

### CI/CD状況
{format_ci_status(data.get("ci_status", []))}
"""
```

### 5.2 出力フォーマットの拡張

```python
OUTPUT_TEMPLATE = """
🌅 **{date} Morning Briefing**

---

**🔴 要対応**
{urgent_items}

---

**📋 昨日の振り返り**
{yesterday_highlights}

---

**📅 本日のスケジュール**
{today_schedule}

---

**✅ 今日のToDo**
{today_tasks}

---

**🔧 開発関連** ← 新規セクション（GitHub追加時）
{dev_items}

---

_Generated at {timestamp} | Sources: {sources}_
"""
```

### 5.3 音声スクリプトへの反映

```python
VOICE_TEMPLATE = """
おはようございます。{date}のブリーフィングです。

まず、対応が必要な項目からお伝えします。
{urgent_narration}

昨日の動きです。
{yesterday_narration}

開発関連では、 ← 新規（GitHub追加時）
{dev_narration}

本日の予定です。
{schedule_narration}

タスクは{task_count}件です。
{tasks_narration}

以上、本日も良い一日を。
"""
```

---

## 6. チェックリスト：新規データソース追加時

```
□ Adapterクラスの実装
  □ BaseAdapterを継承
  □ 全ての抽象メソッドを実装
  □ エラーハンドリングの実装
  □ レート制限対応

□ 認証フローの実装
  □ OAuth対応（該当する場合）
  □ トークンリフレッシュ
  □ 認証エラー時のリカバリー

□ データ正規化
  □ 共通フォーマットへの変換
  □ カテゴリマッピングの定義
  □ 優先度スコアルールの追加

□ 設定
  □ config_schemaの定義
  □ settings.yamlへの追加
  □ credentials.yamlへの追加

□ プロンプト更新
  □ セクションテンプレートの追加
  □ 音声スクリプトへの反映
  □ 出力フォーマットの調整

□ テスト
  □ 単体テストの作成
  □ モックAPIの準備
  □ 統合テストの更新

□ ドキュメント
  □ オンボーディングガイドへの追加
  □ API サンプルの追加
  □ 設定例の追加
```

---

*最終更新: 2025-01-11*
