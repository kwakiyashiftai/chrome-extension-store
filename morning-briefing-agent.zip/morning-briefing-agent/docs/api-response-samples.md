# API レスポンスサンプル集

本ドキュメントでは、モーニング・ブリーフィング・エージェントが取得する各APIのレスポンス形式と、正規化後のデータ構造を定義します。

---

## 1. Slack API レスポンス

### 1.1 チャンネル履歴取得 (`conversations.history`)

**エンドポイント:** `https://slack.com/api/conversations.history`

**リクエスト例:**
```bash
curl -X POST https://slack.com/api/conversations.history \
  -H "Authorization: Bearer xoxb-your-token" \
  -H "Content-Type: application/json" \
  -d '{
    "channel": "C1234567890",
    "oldest": "1704812400",
    "latest": "1704898800",
    "limit": 100
  }'
```

**レスポンス例:**
```json
{
  "ok": true,
  "messages": [
    {
      "type": "message",
      "user": "U1234567890",
      "text": "ロゴの修正案を確認してください <@U0987654321> :pray:",
      "ts": "1704880000.000100",
      "thread_ts": null,
      "reply_count": 0,
      "reactions": [
        {
          "name": "eyes",
          "users": ["U1111111111"],
          "count": 1
        }
      ],
      "attachments": [
        {
          "fallback": "logo_v2.png",
          "image_url": "https://files.slack.com/files-pri/T00000000-F00000000/logo_v2.png",
          "title": "logo_v2.png"
        }
      ]
    },
    {
      "type": "message",
      "user": "U2222222222",
      "text": "プロジェクトBの進捗について報告します。\n\n• デザインフェーズ完了\n• 開発フェーズ50%進捗\n• 来週中にレビュー予定",
      "ts": "1704876000.000200",
      "thread_ts": "1704870000.000050",
      "reply_count": 0,
      "reactions": [
        {
          "name": "+1",
          "users": ["U3333333333", "U4444444444"],
          "count": 2
        }
      ]
    },
    {
      "type": "message",
      "subtype": "bot_message",
      "bot_id": "B1234567890",
      "text": "Daily standup reminder: Please post your updates!",
      "ts": "1704872000.000300"
    },
    {
      "type": "message",
      "user": "U5555555555",
      "text": "<!channel> 明日の定例会議は15時に変更になりました",
      "ts": "1704868000.000400",
      "reactions": []
    }
  ],
  "has_more": false,
  "response_metadata": {
    "next_cursor": ""
  }
}
```

### 1.2 ユーザー情報取得 (`users.info`)

**レスポンス例:**
```json
{
  "ok": true,
  "user": {
    "id": "U1234567890",
    "name": "tanaka.taro",
    "real_name": "田中 太郎",
    "profile": {
      "display_name": "田中",
      "email": "tanaka@example.com",
      "image_72": "https://avatars.slack-edge.com/...",
      "title": "デザイナー"
    },
    "is_bot": false,
    "tz": "Asia/Tokyo"
  }
}
```

### 1.3 自分宛メンション検索 (`search.messages`)

**リクエスト例:**
```bash
curl -X GET "https://slack.com/api/search.messages?query=to:me&sort=timestamp&count=50" \
  -H "Authorization: Bearer xoxb-your-token"
```

**レスポンス例:**
```json
{
  "ok": true,
  "messages": {
    "total": 3,
    "matches": [
      {
        "type": "message",
        "user": "U1234567890",
        "username": "tanaka.taro",
        "text": "<@U0987654321> ロゴの修正案を確認お願いします",
        "ts": "1704880000.000100",
        "channel": {
          "id": "C1234567890",
          "name": "project-a"
        },
        "permalink": "https://yourworkspace.slack.com/archives/C1234567890/p1704880000000100"
      },
      {
        "type": "message",
        "user": "U2222222222",
        "username": "suzuki.hanako",
        "text": "<@U0987654321> 報告書のレビューいただけますか？",
        "ts": "1704870000.000200",
        "channel": {
          "id": "C0000000001",
          "name": "general"
        },
        "permalink": "https://yourworkspace.slack.com/archives/C0000000001/p1704870000000200"
      }
    ]
  }
}
```

### 1.4 正規化後のデータ構造（Slack）

```json
{
  "source": "slack",
  "fetched_at": "2025-01-11T08:50:00+09:00",
  "data": {
    "channel_history": [
      {
        "channel_id": "C1234567890",
        "channel_name": "project-a",
        "messages": [
          {
            "id": "1704880000.000100",
            "author": {
              "id": "U1234567890",
              "name": "田中 太郎",
              "display_name": "田中"
            },
            "content": "ロゴの修正案を確認してください @自分 :pray:",
            "timestamp": "2025-01-10T15:06:40+09:00",
            "mentions_me": true,
            "is_thread_reply": false,
            "reaction_count": 1,
            "has_my_reaction": false,
            "has_my_reply": false,
            "attachments": ["logo_v2.png"],
            "permalink": "https://..."
          }
        ]
      }
    ],
    "pending_mentions": [
      {
        "id": "1704880000.000100",
        "channel_name": "project-a",
        "author_name": "田中 太郎",
        "content": "ロゴの修正案を確認してください",
        "timestamp": "2025-01-10T15:06:40+09:00",
        "hours_since_posted": 18.5,
        "priority_score": 50,
        "permalink": "https://..."
      }
    ],
    "summary_stats": {
      "total_messages": 45,
      "channels_active": 3,
      "mentions_pending": 2,
      "keywords_found": ["緊急", "確認依頼"]
    }
  }
}
```

---

## 2. Google Calendar API レスポンス

### 2.1 イベント一覧取得 (`events.list`)

**エンドポイント:** `https://www.googleapis.com/calendar/v3/calendars/primary/events`

**リクエストパラメータ:**
```
timeMin: 2025-01-11T00:00:00+09:00
timeMax: 2025-01-11T23:59:59+09:00
singleEvents: true
orderBy: startTime
```

**レスポンス例:**
```json
{
  "kind": "calendar#events",
  "summary": "tanaka@example.com",
  "timeZone": "Asia/Tokyo",
  "items": [
    {
      "id": "abc123xyz",
      "status": "confirmed",
      "summary": "内部MTG",
      "description": "週次の進捗確認ミーティング",
      "location": "会議室A",
      "start": {
        "dateTime": "2025-01-11T10:00:00+09:00",
        "timeZone": "Asia/Tokyo"
      },
      "end": {
        "dateTime": "2025-01-11T11:00:00+09:00",
        "timeZone": "Asia/Tokyo"
      },
      "attendees": [
        {
          "email": "tanaka@example.com",
          "displayName": "田中 太郎",
          "responseStatus": "accepted",
          "self": true
        },
        {
          "email": "suzuki@example.com",
          "displayName": "鈴木 花子",
          "responseStatus": "accepted"
        },
        {
          "email": "yamada@example.com",
          "displayName": "山田 次郎",
          "responseStatus": "needsAction"
        }
      ],
      "organizer": {
        "email": "suzuki@example.com",
        "displayName": "鈴木 花子"
      },
      "conferenceData": null
    },
    {
      "id": "def456uvw",
      "status": "confirmed",
      "summary": "クライアント商談",
      "description": "新規案件のヒアリング",
      "location": null,
      "start": {
        "dateTime": "2025-01-11T15:00:00+09:00",
        "timeZone": "Asia/Tokyo"
      },
      "end": {
        "dateTime": "2025-01-11T16:00:00+09:00",
        "timeZone": "Asia/Tokyo"
      },
      "attendees": [
        {
          "email": "tanaka@example.com",
          "displayName": "田中 太郎",
          "responseStatus": "accepted",
          "self": true
        },
        {
          "email": "client@external.com",
          "displayName": "クライアント担当者",
          "responseStatus": "accepted"
        }
      ],
      "conferenceData": {
        "entryPoints": [
          {
            "entryPointType": "video",
            "uri": "https://zoom.us/j/1234567890",
            "label": "zoom.us"
          }
        ],
        "conferenceSolution": {
          "name": "Zoom Meeting"
        }
      },
      "hangoutLink": null
    },
    {
      "id": "ghi789rst",
      "status": "cancelled",
      "summary": "キャンセルされた会議",
      "start": {
        "dateTime": "2025-01-11T14:00:00+09:00",
        "timeZone": "Asia/Tokyo"
      },
      "end": {
        "dateTime": "2025-01-11T14:30:00+09:00",
        "timeZone": "Asia/Tokyo"
      }
    }
  ]
}
```

### 2.2 正規化後のデータ構造（Calendar）

```json
{
  "source": "google_calendar",
  "fetched_at": "2025-01-11T08:50:00+09:00",
  "data": {
    "date": "2025-01-11",
    "timezone": "Asia/Tokyo",
    "events": [
      {
        "id": "abc123xyz",
        "title": "内部MTG",
        "description": "週次の進捗確認ミーティング",
        "start_time": "10:00",
        "end_time": "11:00",
        "duration_minutes": 60,
        "location": {
          "type": "physical",
          "name": "会議室A",
          "url": null
        },
        "attendees_count": 3,
        "is_organizer": false,
        "my_response": "accepted",
        "has_video_call": false
      },
      {
        "id": "def456uvw",
        "title": "クライアント商談",
        "description": "新規案件のヒアリング",
        "start_time": "15:00",
        "end_time": "16:00",
        "duration_minutes": 60,
        "location": {
          "type": "virtual",
          "name": "Zoom Meeting",
          "url": "https://zoom.us/j/1234567890"
        },
        "attendees_count": 2,
        "is_organizer": false,
        "my_response": "accepted",
        "has_video_call": true,
        "is_external_meeting": true
      }
    ],
    "summary_stats": {
      "total_events": 2,
      "total_meeting_hours": 2.0,
      "external_meetings": 1,
      "video_calls": 1,
      "busiest_period": "午後"
    }
  }
}
```

---

## 3. Google Docs API レスポンス

### 3.1 ドキュメント取得 (`documents.get`)

**エンドポイント:** `https://docs.googleapis.com/v1/documents/{documentId}`

**レスポンス例（簡略化）:**
```json
{
  "documentId": "1abc2def3ghi4jkl5mno",
  "title": "2025年1月10日 プロジェクトA 定例会議 議事録",
  "body": {
    "content": [
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "2025年1月10日 プロジェクトA 定例会議 議事録\n",
                "textStyle": {
                  "bold": true,
                  "fontSize": {
                    "magnitude": 18,
                    "unit": "PT"
                  }
                }
              }
            }
          ],
          "paragraphStyle": {
            "namedStyleType": "HEADING_1"
          }
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "参加者\n",
                "textStyle": {
                  "bold": true
                }
              }
            }
          ],
          "paragraphStyle": {
            "namedStyleType": "HEADING_2"
          }
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "田中、鈴木、山田、佐藤\n"
              }
            }
          ]
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "決定事項\n",
                "textStyle": {
                  "bold": true
                }
              }
            }
          ],
          "paragraphStyle": {
            "namedStyleType": "HEADING_2"
          }
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "• 次期フェーズの予算を20%増額することで合意\n"
              }
            }
          ]
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "• リリース日を2月15日に確定\n"
              }
            }
          ]
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "ネクストアクション\n",
                "textStyle": {
                  "bold": true
                }
              }
            }
          ],
          "paragraphStyle": {
            "namedStyleType": "HEADING_2"
          }
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "• 【田中】デザインレビューを1/12までに完了\n"
              }
            }
          ]
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "• 【鈴木】開発環境のセットアップを1/13までに完了\n"
              }
            }
          ]
        }
      },
      {
        "paragraph": {
          "elements": [
            {
              "textRun": {
                "content": "• 【山田】クライアントへの報告資料作成を1/14までに\n"
              }
            }
          ]
        }
      }
    ]
  },
  "revisionId": "ALm37BWxyz...",
  "suggestionsViewMode": "PREVIEW_WITHOUT_SUGGESTIONS"
}
```

### 3.2 Drive ファイル一覧取得 (`files.list`)

**リクエスト:**
```
q: '1234567890' in parents and mimeType='application/vnd.google-apps.document' and modifiedTime > '2025-01-10T00:00:00'
orderBy: modifiedTime desc
```

**レスポンス例:**
```json
{
  "kind": "drive#fileList",
  "files": [
    {
      "id": "1abc2def3ghi4jkl5mno",
      "name": "2025年1月10日 プロジェクトA 定例会議 議事録",
      "mimeType": "application/vnd.google-apps.document",
      "modifiedTime": "2025-01-10T18:30:00.000Z",
      "lastModifyingUser": {
        "displayName": "鈴木 花子",
        "emailAddress": "suzuki@example.com"
      },
      "webViewLink": "https://docs.google.com/document/d/1abc2def3ghi4jkl5mno/edit"
    },
    {
      "id": "2bcd3efg4hij5klm6nop",
      "name": "2025年1月10日 営業MTG メモ",
      "mimeType": "application/vnd.google-apps.document",
      "modifiedTime": "2025-01-10T16:00:00.000Z",
      "lastModifyingUser": {
        "displayName": "田中 太郎",
        "emailAddress": "tanaka@example.com"
      },
      "webViewLink": "https://docs.google.com/document/d/2bcd3efg4hij5klm6nop/edit"
    }
  ]
}
```

### 3.3 正規化後のデータ構造（Docs）

```json
{
  "source": "google_docs",
  "fetched_at": "2025-01-11T08:50:00+09:00",
  "data": {
    "meeting_notes": [
      {
        "document_id": "1abc2def3ghi4jkl5mno",
        "title": "2025年1月10日 プロジェクトA 定例会議 議事録",
        "meeting_date": "2025-01-10",
        "last_modified": "2025-01-10T18:30:00+09:00",
        "last_modified_by": "鈴木 花子",
        "url": "https://docs.google.com/document/d/.../edit",
        "extracted": {
          "participants": ["田中", "鈴木", "山田", "佐藤"],
          "decisions": [
            "次期フェーズの予算を20%増額することで合意",
            "リリース日を2月15日に確定"
          ],
          "action_items": [
            {
              "assignee": "田中",
              "task": "デザインレビューを完了",
              "due_date": "2025-01-12",
              "is_my_task": true
            },
            {
              "assignee": "鈴木",
              "task": "開発環境のセットアップを完了",
              "due_date": "2025-01-13",
              "is_my_task": false
            },
            {
              "assignee": "山田",
              "task": "クライアントへの報告資料作成",
              "due_date": "2025-01-14",
              "is_my_task": false
            }
          ]
        }
      }
    ],
    "summary_stats": {
      "documents_found": 2,
      "total_decisions": 2,
      "total_action_items": 3,
      "my_action_items": 1
    }
  }
}
```

---

## 4. ToDo API レスポンス（Todoist例）

### 4.1 タスク一覧取得

**エンドポイント:** `https://api.todoist.com/rest/v2/tasks`

**レスポンス例:**
```json
[
  {
    "id": "7654321098",
    "content": "報告書の提出",
    "description": "Q4のレポートを経理に提出",
    "project_id": "2203456789",
    "section_id": null,
    "parent_id": null,
    "order": 1,
    "priority": 4,
    "due": {
      "date": "2025-01-11",
      "string": "今日",
      "lang": "ja",
      "is_recurring": false,
      "datetime": "2025-01-11T18:00:00"
    },
    "labels": ["仕事", "重要"],
    "created_at": "2025-01-08T10:00:00Z",
    "creator_id": "12345678",
    "assignee_id": null,
    "url": "https://todoist.com/showTask?id=7654321098"
  },
  {
    "id": "7654321099",
    "content": "デザインレビュー",
    "description": "",
    "project_id": "2203456789",
    "priority": 3,
    "due": {
      "date": "2025-01-11",
      "string": "今日",
      "lang": "ja",
      "is_recurring": false
    },
    "labels": ["仕事"],
    "created_at": "2025-01-10T14:00:00Z",
    "url": "https://todoist.com/showTask?id=7654321099"
  },
  {
    "id": "7654321100",
    "content": "経費精算",
    "description": "12月分の経費精算",
    "project_id": "2203456790",
    "priority": 2,
    "due": {
      "date": "2025-01-10",
      "string": "昨日",
      "lang": "ja",
      "is_recurring": false
    },
    "labels": ["仕事"],
    "created_at": "2025-01-05T09:00:00Z",
    "url": "https://todoist.com/showTask?id=7654321100"
  }
]
```

### 4.2 正規化後のデータ構造（ToDo）

```json
{
  "source": "todoist",
  "fetched_at": "2025-01-11T08:50:00+09:00",
  "data": {
    "tasks": {
      "overdue": [
        {
          "id": "7654321100",
          "title": "経費精算",
          "description": "12月分の経費精算",
          "due_date": "2025-01-10",
          "due_time": null,
          "days_overdue": 1,
          "priority": "medium",
          "priority_score": 25,
          "labels": ["仕事"],
          "url": "https://todoist.com/showTask?id=7654321100"
        }
      ],
      "today": [
        {
          "id": "7654321098",
          "title": "報告書の提出",
          "description": "Q4のレポートを経理に提出",
          "due_date": "2025-01-11",
          "due_time": "18:00",
          "priority": "urgent",
          "priority_score": 15,
          "labels": ["仕事", "重要"],
          "url": "https://todoist.com/showTask?id=7654321098"
        },
        {
          "id": "7654321099",
          "title": "デザインレビュー",
          "description": "",
          "due_date": "2025-01-11",
          "due_time": null,
          "priority": "high",
          "priority_score": 10,
          "labels": ["仕事"],
          "url": "https://todoist.com/showTask?id=7654321099"
        }
      ]
    },
    "summary_stats": {
      "overdue_count": 1,
      "today_count": 2,
      "urgent_count": 1,
      "total_priority_score": 50
    }
  }
}
```

---

## 5. 統合データ構造

すべてのソースからデータを取得後、以下の形式に統合してLLMに渡します。

```json
{
  "briefing_request": {
    "generated_at": "2025-01-11T08:55:00+09:00",
    "target_date": "2025-01-11",
    "user": {
      "name": "田中 太郎",
      "timezone": "Asia/Tokyo",
      "language": "ja"
    },
    "data_sources": {
      "slack": {
        "status": "success",
        "fetched_at": "2025-01-11T08:50:15+09:00"
      },
      "google_calendar": {
        "status": "success",
        "fetched_at": "2025-01-11T08:50:20+09:00"
      },
      "google_docs": {
        "status": "success",
        "fetched_at": "2025-01-11T08:50:25+09:00"
      },
      "todoist": {
        "status": "success",
        "fetched_at": "2025-01-11T08:50:30+09:00"
      }
    },
    "aggregated_data": {
      "urgent_items": [
        {
          "source": "slack",
          "type": "pending_mention",
          "priority_score": 50,
          "summary": "田中さんからロゴ修正案の確認依頼（24時間経過）",
          "detail": {
            "author": "田中 太郎",
            "channel": "project-a",
            "hours_since": 18.5
          }
        },
        {
          "source": "todoist",
          "type": "overdue_task",
          "priority_score": 25,
          "summary": "経費精算（1日超過）",
          "detail": {
            "task": "経費精算",
            "days_overdue": 1
          }
        }
      ],
      "yesterday_highlights": [
        {
          "source": "slack",
          "type": "discussion",
          "summary": "プロジェクトBの進捗について合意形成"
        },
        {
          "source": "google_docs",
          "type": "decision",
          "summary": "次期フェーズの予算を20%増額で決定"
        },
        {
          "source": "google_docs",
          "type": "decision",
          "summary": "リリース日を2月15日に確定"
        }
      ],
      "today_schedule": [
        {
          "time": "10:00-11:00",
          "title": "内部MTG",
          "location": "会議室A",
          "type": "internal"
        },
        {
          "time": "15:00-16:00",
          "title": "クライアント商談",
          "location": "Zoom",
          "type": "external",
          "meeting_url": "https://zoom.us/j/1234567890"
        }
      ],
      "today_tasks": [
        {
          "title": "報告書の提出",
          "due_time": "18:00",
          "priority": "urgent"
        },
        {
          "title": "デザインレビュー",
          "due_time": null,
          "priority": "high",
          "from_meeting": true
        }
      ],
      "my_action_items_from_meetings": [
        {
          "task": "デザインレビューを完了",
          "due_date": "2025-01-12",
          "from_meeting": "プロジェクトA 定例会議"
        }
      ]
    },
    "statistics": {
      "total_priority_score": 75,
      "meeting_hours_today": 2.0,
      "pending_mentions": 1,
      "overdue_tasks": 1,
      "today_tasks": 2
    }
  }
}
```

---

## 6. エラーレスポンスのサンプル

### 6.1 Slack認証エラー

```json
{
  "ok": false,
  "error": "invalid_auth",
  "warning": "missing_charset",
  "response_metadata": {
    "warnings": ["missing_charset"]
  }
}
```

### 6.2 Googleレート制限

```json
{
  "error": {
    "code": 429,
    "message": "Rate Limit Exceeded",
    "errors": [
      {
        "message": "Rate Limit Exceeded",
        "domain": "usageLimits",
        "reason": "rateLimitExceeded"
      }
    ]
  }
}
```

### 6.3 正規化されたエラー構造

```json
{
  "source": "slack",
  "fetched_at": "2025-01-11T08:50:15+09:00",
  "status": "error",
  "error": {
    "code": "AUTH_INVALID",
    "message": "Slack認証トークンが無効です",
    "recoverable": true,
    "action_required": "再認証が必要です",
    "retry_after": null
  },
  "data": null
}
```

---

*最終更新: 2025-01-11*
