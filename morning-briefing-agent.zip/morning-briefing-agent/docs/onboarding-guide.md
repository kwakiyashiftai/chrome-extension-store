# モーニング・ブリーフィング・エージェント オンボーディングガイド

**バージョン:** 1.0  
**対象者:** 初回セットアップを行うユーザー・開発者

---

## 目次

1. [はじめに](#1-はじめに)
2. [システム要件](#2-システム要件)
3. [Mistral（ローカルLLM）のセットアップ](#3-mistralローカルllmのセットアップ)
4. [外部サービス連携の設定](#4-外部サービス連携の設定)
5. [初期設定ウィザード](#5-初期設定ウィザード)
6. [テスト実行](#6-テスト実行)
7. [トラブルシューティング](#7-トラブルシューティング)

---

## 1. はじめに

### 1.1 このガイドについて

このガイドでは、モーニング・ブリーフィング・エージェントを初めてセットアップする際の手順を説明します。所要時間は約30〜60分です。

### 1.2 全体の流れ

```
┌─────────────────────────────────────────────────────────────────┐
│  Step 1        Step 2         Step 3        Step 4             │
│  ─────────    ──────────     ──────────    ──────────          │
│  環境構築  →  Mistral設定  →  API連携設定  →  テスト実行        │
│  (15分)       (15分)         (20分)        (10分)              │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. システム要件

### 2.1 ハードウェア要件

| 項目 | 最小要件 | 推奨要件 |
|------|---------|---------|
| CPU | 4コア | 8コア以上 |
| RAM | 16GB | 32GB以上 |
| GPU | - | NVIDIA RTX 3060以上（VRAM 8GB+） |
| ストレージ | 20GB空き | 50GB以上空き（SSD推奨） |

### 2.2 ソフトウェア要件

| ソフトウェア | バージョン | 用途 |
|-------------|-----------|------|
| Python | 3.10以上 | メイン実行環境 |
| Node.js | 18以上 | 一部ツール用（オプション） |
| Docker | 24以上 | Mistral実行環境（推奨） |
| Git | 最新版 | ソースコード管理 |

### 2.3 必要なアカウント

| サービス | 必須/任意 | プラン要件 |
|---------|----------|-----------|
| Slack | 必須 | 無料プランでも可（履歴取得に制限あり） |
| Google Workspace | 必須 | 個人Gmail可、Business推奨 |
| Todoist / Notion | 任意 | 無料プランで可 |
| Mistral AI | 任意 | ローカル実行なら不要 |

---

## 3. Mistral（ローカルLLM）のセットアップ

### 3.1 Mistralモデルの選択

| モデル | サイズ | VRAM要件 | 推奨用途 |
|--------|-------|---------|---------|
| Mistral 7B Instruct | 7B | 8GB | 軽量環境、基本的な要約 |
| Mixtral 8x7B | 47B | 24GB | 高品質な要約、複雑な判断 |
| Mistral Small | API | - | ローカル実行が難しい場合 |

**推奨:** Mistral 7B Instruct（バランスが良い）

### 3.2 Ollama を使ったセットアップ（推奨）

Ollamaを使うと、最も簡単にローカルLLMを実行できます。

#### Step 1: Ollamaのインストール

```bash
# macOS
brew install ollama

# Linux
curl -fsSL https://ollama.com/install.sh | sh

# Windows
# https://ollama.com/download からインストーラーをダウンロード
```

#### Step 2: Mistralモデルのダウンロード

```bash
# Mistral 7B Instruct（推奨）
ollama pull mistral

# より高性能なMixtral（GPUメモリに余裕がある場合）
ollama pull mixtral
```

#### Step 3: 動作確認

```bash
# Ollamaサーバー起動（別ターミナルで）
ollama serve

# テスト実行
curl http://localhost:11434/api/generate -d '{
  "model": "mistral",
  "prompt": "今日のタスクを3つ箇条書きで教えてください",
  "stream": false
}'
```

### 3.3 vLLM を使ったセットアップ（高性能版）

より高いスループットが必要な場合はvLLMを使用します。

#### Step 1: vLLMのインストール

```bash
pip install vllm
```

#### Step 2: サーバー起動

```bash
python -m vllm.entrypoints.openai.api_server \
  --model mistralai/Mistral-7B-Instruct-v0.2 \
  --host 0.0.0.0 \
  --port 8000
```

#### Step 3: OpenAI互換APIとして利用

```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="dummy"  # ローカルなので任意の値
)

response = client.chat.completions.create(
    model="mistralai/Mistral-7B-Instruct-v0.2",
    messages=[{"role": "user", "content": "こんにちは"}]
)
```

### 3.4 Docker Composeでの統合セットアップ

```yaml
# docker-compose.yml
version: '3.8'

services:
  ollama:
    image: ollama/ollama:latest
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]

  briefing-agent:
    build: .
    depends_on:
      - ollama
    environment:
      - LLM_BASE_URL=http://ollama:11434
      - LLM_MODEL=mistral
    volumes:
      - ./config:/app/config

volumes:
  ollama_data:
```

### 3.5 設定ファイル

```yaml
# config/llm.yaml
llm:
  provider: "ollama"  # ollama | vllm | mistral-api
  base_url: "http://localhost:11434"
  model: "mistral"
  
  # 生成パラメータ
  temperature: 0.3  # 要約は低めが安定
  max_tokens: 2000
  top_p: 0.9
  
  # タイムアウト設定
  timeout_seconds: 60
  retry_count: 3

  # フォールバック（ローカルが失敗した場合）
  fallback:
    enabled: true
    provider: "mistral-api"
    api_key: "${MISTRAL_API_KEY}"  # 環境変数から
```

---

## 4. 外部サービス連携の設定

### 4.1 Slack連携

#### Step 1: Slack Appの作成

1. [Slack API](https://api.slack.com/apps) にアクセス
2. 「Create New App」→「From scratch」を選択
3. App名: `Morning Briefing Agent`
4. Workspaceを選択

#### Step 2: 必要な権限（Scopes）の設定

**Bot Token Scopes（必須）:**

| Scope | 用途 |
|-------|------|
| `channels:history` | パブリックチャンネルの履歴取得 |
| `channels:read` | チャンネル一覧の取得 |
| `groups:history` | プライベートチャンネルの履歴取得 |
| `groups:read` | プライベートチャンネル一覧取得 |
| `im:history` | DMの履歴取得 |
| `im:read` | DM一覧の取得 |
| `mpim:history` | グループDMの履歴取得 |
| `chat:write` | メッセージ送信（配信用） |
| `files:write` | ファイルアップロード（音声用） |
| `users:read` | ユーザー情報取得 |

#### Step 3: トークンの取得

1. 「OAuth & Permissions」→「Install to Workspace」
2. `xoxb-` で始まるBot Tokenをコピー
3. 設定ファイルに保存（後述）

#### Step 4: イベント購読（オプション）

リアルタイム通知が必要な場合は「Event Subscriptions」を設定

### 4.2 Google連携

#### Step 1: Google Cloud Projectの作成

1. [Google Cloud Console](https://console.cloud.google.com/) にアクセス
2. 新規プロジェクト作成: `morning-briefing`

#### Step 2: APIの有効化

以下のAPIを有効化:
- Google Calendar API
- Google Docs API
- Google Drive API

#### Step 3: OAuth 2.0認証情報の作成

1. 「APIs & Services」→「Credentials」
2. 「Create Credentials」→「OAuth client ID」
3. Application type: 「Desktop app」
4. クライアントID・シークレットを保存

#### Step 4: 必要なスコープ

```
https://www.googleapis.com/auth/calendar.readonly
https://www.googleapis.com/auth/documents.readonly
https://www.googleapis.com/auth/drive.readonly
```

### 4.3 認証情報の保存

```yaml
# config/credentials.yaml（.gitignoreに追加すること）
slack:
  bot_token: "xoxb-xxxxxxxxxxxx-xxxxxxxxxxxx-xxxxxxxxxxxxxxxxxxxxxxxx"
  signing_secret: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

google:
  client_id: "xxxxxxxxxxxx.apps.googleusercontent.com"
  client_secret: "GOCSPX-xxxxxxxxxxxxxxxxxxxxxxxx"
  # 初回認証後に自動保存される
  refresh_token: null

todoist:  # オプション
  api_token: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

**セキュリティ注意:**
- このファイルは絶対にGitにコミットしない
- 本番環境では環境変数または Secret Manager を使用

---

## 5. 初期設定ウィザード

### 5.1 セットアップスクリプトの実行

```bash
# リポジトリのクローン
git clone https://github.com/your-org/morning-briefing-agent.git
cd morning-briefing-agent

# 依存関係のインストール
pip install -r requirements.txt

# 初期設定ウィザード起動
python setup_wizard.py
```

### 5.2 ウィザードの流れ

```
┌─────────────────────────────────────────────────────────────────┐
│  🌅 モーニング・ブリーフィング・エージェント セットアップ        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Step 1/5: LLM設定                                              │
│  ────────────────                                               │
│  使用するLLMを選択してください:                                   │
│  [1] Ollama (ローカル) ← 推奨                                    │
│  [2] vLLM (ローカル・高性能)                                     │
│  [3] Mistral API (クラウド)                                      │
│                                                                 │
│  選択: 1                                                        │
│                                                                 │
│  Ollamaの接続確認中... ✅ 接続成功 (mistral モデル検出)          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  Step 2/5: Slack連携                                            │
│  ──────────────────                                             │
│  Bot Token (xoxb-...): ********************************         │
│                                                                 │
│  認証確認中... ✅ 認証成功 (Workspace: Your Company)             │
│                                                                 │
│  監視するチャンネルを選択 (スペース区切り):                       │
│  利用可能: #general, #project-a, #random, #engineering          │
│                                                                 │
│  選択: general project-a engineering                            │
│                                                                 │
│  配信先チャンネル/DM: @your-username                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  Step 3/5: Google連携                                           │
│  ───────────────────                                            │
│  ブラウザで認証画面を開きます...                                  │
│                                                                 │
│  ✅ Google Calendar 接続成功                                     │
│  ✅ Google Docs 接続成功                                         │
│  ✅ Google Drive 接続成功                                        │
│                                                                 │
│  議事録フォルダを選択:                                           │
│  [1] My Drive / 議事録                                          │
│  [2] Shared / プロジェクトA / 議事録                             │
│  [3] 手動でフォルダIDを入力                                      │
│                                                                 │
│  選択: 2                                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  Step 4/5: 配信設定                                              │
│  ───────────────                                                │
│  配信時刻 (HH:MM): 09:00                                        │
│  タイムゾーン: Asia/Tokyo                                        │
│  週末を除外: [Y/n] Y                                            │
│  音声配信: [Y/n] Y                                              │
│  言語: [1] 日本語  [2] English                                  │
│  選択: 1                                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  Step 5/5: 設定確認                                              │
│  ───────────────                                                │
│                                                                 │
│  📋 設定内容:                                                    │
│  ├─ LLM: Ollama (mistral)                                       │
│  ├─ Slack: Your Company                                         │
│  │   ├─ 監視: #general, #project-a, #engineering                │
│  │   └─ 配信: @your-username                                    │
│  ├─ Google: 連携済み                                            │
│  │   └─ 議事録: Shared/プロジェクトA/議事録                      │
│  └─ 配信: 毎日 09:00 JST (土日除く)                              │
│                                                                 │
│  この設定で開始しますか？ [Y/n] Y                                │
│                                                                 │
│  ✅ 設定を保存しました: config/settings.yaml                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. テスト実行

### 6.1 個別コンポーネントのテスト

```bash
# LLM接続テスト
python -m briefing.test_llm

# Slack接続テスト
python -m briefing.test_slack

# Google接続テスト
python -m briefing.test_google

# 全体統合テスト
python -m briefing.test_all
```

### 6.2 手動でブリーフィングを生成

```bash
# 即座に実行（配信なし、プレビューのみ）
python -m briefing.run --preview

# 即座に実行（実際に配信）
python -m briefing.run --now

# 特定の日付のデータで実行
python -m briefing.run --date 2025-01-10 --preview
```

### 6.3 期待される出力

```
🌅 2025/1/11 (土) Morning Briefing

---

🔴 要対応
• 【Slack】△△さんより：ロゴ修正案の確認依頼（未返信・24時間経過）

---

📋 昨日の振り返り
• プロジェクトBの進捗についてチーム内で合意形成済み

---

📅 本日のスケジュール
• 10:00-11:00 内部MTG（会議室A）
• 15:00-16:00 商談（Zoom）

---

✅ 今日のToDo
• 報告書の提出（18:00締切）

---
Generated at 2025-01-11 09:00 JST | Model: mistral (local)
```

### 6.4 スケジューラーの設定

```bash
# cron登録（Linux/Mac）
crontab -e

# 以下を追加（毎日8:50に実行）
50 8 * * 1-5 cd /path/to/morning-briefing-agent && python -m briefing.run

# systemdサービス化（推奨）
sudo cp deploy/briefing.service /etc/systemd/system/
sudo systemctl enable briefing
sudo systemctl start briefing
```

---

## 7. トラブルシューティング

### 7.1 よくある問題と解決策

| 症状 | 原因 | 解決策 |
|------|------|--------|
| Ollamaに接続できない | サーバー未起動 | `ollama serve` を実行 |
| Mistralモデルが遅い | GPUが使われていない | `nvidia-smi` で確認、CUDAドライバ更新 |
| Slack認証エラー | トークン期限切れ | 再度OAuth認証を実行 |
| Google認証エラー | リフレッシュトークン無効 | `config/google_token.json` を削除して再認証 |
| 要約が途中で切れる | max_tokens不足 | `config/llm.yaml` の `max_tokens` を増加 |
| 日本語が文字化け | エンコーディング問題 | 環境変数 `PYTHONIOENCODING=utf-8` を設定 |

### 7.2 ログの確認

```bash
# アプリケーションログ
tail -f logs/briefing.log

# Ollamaログ
journalctl -u ollama -f

# デバッグモードで実行
python -m briefing.run --debug
```

### 7.3 サポート

問題が解決しない場合:
1. GitHubのIssueを確認
2. 新規Issueを作成（ログを添付）
3. Slackの #support チャンネルで質問

---

## 次のステップ

セットアップが完了したら:

1. **[運用ガイド](./operation-guide.md)** - 日常の運用・監視方法
2. **[カスタマイズガイド](./customization-guide.md)** - プロンプト調整、出力形式変更
3. **[拡張ガイド](./extension-guide.md)** - 新しいデータソースの追加方法

---

*最終更新: 2025-01-11*
