# 🌅 モーニング・ブリーフィング・エージェント

毎朝、複数のツール（Slack, Google Workspace等）に散らばった情報をAIが統合・要約し、音声とテキストで提供するエージェントシステム。

## 特徴

- 🤖 **AI要約**: Mistral LLMによる高品質な要約生成
- 📊 **複数ソース統合**: Slack、Google Calendar、Google Docs、Todoistに対応
- 🎯 **優先度判定**: 重要度に基づく自動分類
- 🔊 **音声配信**: TTS音声スクリプト生成
- 💰 **低コスト**: ローカル実行で月額¥15〜（Mistral API利用で月額¥110〜）
- 🔒 **プライバシー**: データをローカル処理、学習に使用されない

## システム要件

- Python 3.10以上
- (オプション) NVIDIA GPU (VRAM 8GB以上、ローカルLLM実行時)
- Slack、Google Workspaceアカウント

## クイックスタート

### 1. インストール

```bash
# リポジトリのクローン
git clone <repository-url>
cd morning-briefing-agent

# 仮想環境の作成
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 依存関係のインストール
pip install -r requirements.txt
```

### 2. 設定

```bash
# 環境変数の設定
cp .env.example .env
# .envファイルを編集してAPIキーを設定

# 設定ファイルの作成
cp config/settings.yaml.example config/settings.yaml
cp config/credentials.yaml.example config/credentials.yaml
# credentials.yamlを編集して認証情報を設定
```

### 3. 認証

```bash
# Google認証
python -m briefing.setup_google_auth

# Slack認証は.envのトークンで完了
```

### 4. テスト実行

```bash
# プレビュー（配信なし）
python -m briefing.run --preview

# 実際に配信
python -m briefing.run --now
```

### 5. スケジューラー設定

```bash
# cronで毎朝8:50に実行
crontab -e

# 以下を追加
50 8 * * 1-5 cd /path/to/morning-briefing-agent && /path/to/venv/bin/python -m briefing.run
```

## プロジェクト構造

```
morning-briefing-agent/
├── briefing/                   # メインパッケージ
│   ├── adapters/              # データソースアダプター
│   │   ├── base.py           # 基底クラス
│   │   ├── slack_adapter.py
│   │   ├── google_calendar_adapter.py
│   │   └── google_docs_adapter.py
│   ├── agent/                 # AI処理
│   │   ├── mistral_agent.py  # Mistral統合
│   │   └── prompts.py        # プロンプトテンプレート
│   ├── core/                  # コアロジック
│   │   ├── aggregator.py     # データ統合
│   │   ├── priority.py       # 優先度判定
│   │   └── normalizer.py     # データ正規化
│   ├── output/                # 出力
│   │   ├── slack_sender.py   # Slack配信
│   │   └── tts.py            # 音声生成
│   └── run.py                 # メインスクリプト
├── config/                     # 設定ファイル
├── tests/                      # テスト
└── logs/                       # ログ
```

## 使い方

### コマンドラインオプション

```bash
# プレビューモード（配信なし）
python -m briefing.run --preview

# 即時実行（配信あり）
python -m briefing.run --now

# 特定日付のデータで実行
python -m briefing.run --date 2025-01-11 --preview

# デバッグモード
python -m briefing.run --debug
```

### 設定ファイル

`config/settings.yaml`で以下を設定できます：

- 配信時刻
- 監視対象チャンネル
- 議事録フォルダID
- 音声配信の有無
- 言語設定

## 開発

### テスト

```bash
# 全テスト実行
pytest

# 特定のテスト
pytest tests/test_slack_adapter.py

# カバレッジ付き
pytest --cov=briefing tests/
```

### コードフォーマット

```bash
# フォーマット
black briefing/

# リント
flake8 briefing/

# 型チェック
mypy briefing/
```

## トラブルシューティング

### Ollamaに接続できない

```bash
# Ollamaサーバーを起動
ollama serve
```

### Google認証エラー

```bash
# トークンを削除して再認証
rm config/google_token.json
python -m briefing.setup_google_auth
```

### ログの確認

```bash
# アプリケーションログ
tail -f logs/briefing.log

# デバッグモードで実行
python -m briefing.run --debug
```

## コスト

### ローカル実行（推奨）

- LLM: Mistral 7B（ローカル） - 無料
- TTS: Coqui TTS（ローカル） - 無料
- 電気代: 約¥15/月

### クラウドAPI利用

- LLM: Mistral Medium API - 約¥55/月
- TTS: Google Cloud TTS - 約¥55/月
- **合計**: 約¥110/月

## ドキュメント

詳細なドキュメントは`docs/`フォルダを参照してください：

- [オンボーディングガイド](docs/onboarding-guide.md)
- [Mistral Agent統合](docs/mistral-agent-integration.md)
- [拡張ガイド](docs/extension-guide.md)
- [API レスポンスサンプル](docs/api-response-samples.md)

## ライセンス

MIT License

## 貢献

Issue、Pull Requestを歓迎します！

---

**Created with ❤️ using Claude Code**
